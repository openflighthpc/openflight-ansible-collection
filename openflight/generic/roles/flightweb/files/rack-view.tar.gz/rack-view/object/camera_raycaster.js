import * as THREE from '../three.module.min.js'
import {
} from '../spec.js'
import * as ThreeCamera from './camera.js'

export const NODE_MODE = 0;
export const SLOT_MODE = 1;
export const newCameraRaycaster = function (camera) {
  return new CameraRaycaster(camera);
}

class CameraRaycaster {

  /**
   * @param {Camera} camera The camera that is used as the of the origin of the raycaster.
   */
  constructor (camera) {
    this.raycaster = new THREE.Raycaster();
    this.mouseVector = new THREE.Vector2(0, 0);
    this.camera = camera;
    this.mode = NODE_MODE;
    /**
     * @type {object|undefined}
     */
    this.firstIntersectedObject = undefined;
  }

  updateVector(e) {
    const viewportDimensions = e.target.getBoundingClientRect();
    const mouseX = (e.clientX - viewportDimensions.left) / viewportDimensions.width * 2 - 1;
    const mouseY = 1 - (e.clientY - viewportDimensions.top) / viewportDimensions.height * 2;
    this.mouseVector.x = mouseX;
    this.mouseVector.y = mouseY;
  }

  notifyNextFrame() {
    this.raycaster.setFromCamera(this.mouseVector, this.camera.camera);
    // check node intersects
    if (this.mode === NODE_MODE) {
      const firstIntersection = this.raycaster.intersectObjects(this.camera.focusingCluster.getNodePanelMeshes())[0];
      if (firstIntersection === undefined) {
        this.firstIntersectedObject = undefined;
        return;
      }
      this.firstIntersectedObject = firstIntersection.object.userData.flightObj;
    } else if (this.mode === SLOT_MODE) {
      const firstIntersection = this.raycaster.intersectObjects(this.camera.focusingCluster.getSlotMeshes())[0];
      if (firstIntersection === undefined) {
        this.firstIntersectedObject = undefined;
        return;
      }
      this.firstIntersectedObject = firstIntersection.object.userData.flightObj;
    }

  }
}

