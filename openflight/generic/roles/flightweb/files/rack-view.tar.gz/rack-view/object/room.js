import * as THREE from '../three.module.min.js'

import {
  newCeilingMesh,
  newFloorMesh,
  newWallMesh
} from '../mesh.js'

import {
  floorTileWidth,
  floorTileDepth
} from '../spec.js'

/**
   * 
   * @returns {Room}
   */
export const newRoom = function (horizontalTileNumber, verticalTileNumber) {
  return new Room(horizontalTileNumber, verticalTileNumber);
}

/**
 * The room mesh as well as its relevant data.
 */
class Room {

  constructor(horizontalTileNumber, verticalTileNumber) {

    const groupMesh = new THREE.Group();
    groupMesh.userData.flightObj = this;

      const ceilingMesh = newCeilingMesh(horizontalTileNumber, verticalTileNumber);
      const floorMesh = newFloorMesh(horizontalTileNumber, verticalTileNumber);
      const wallMesh = newWallMesh(horizontalTileNumber, verticalTileNumber);

    groupMesh.add(ceilingMesh, floorMesh, wallMesh);

    const roomWidth = horizontalTileNumber * floorTileWidth;
    const roomDepth = verticalTileNumber * floorTileDepth;
    let tiles = [];
    for (let x = 0; x < horizontalTileNumber; x++) {
      tiles.push([]);
      for (let z = 0; z < verticalTileNumber; z++) {
        const tilePositionX = (x + 0.5) * floorTileWidth - roomWidth / 2;
        const tilePositionZ = (z + 0.5) * floorTileDepth - roomDepth / 2;
        tiles[x].push(new RoomTile(x, z, tilePositionX, tilePositionZ));
      }
    }

    this.horizontalTileNumber = horizontalTileNumber;
    this.verticalTileNumber = verticalTileNumber;    
    this.groupMesh = groupMesh;
    /**
     * @type {RoomTile[][]}
     */
    this.tiles = tiles;
    /**
     * @type {Cluster[]}
     */
    this.clusters = [];
  }

  getClusterMeshes () {
    let meshes = [];
    for (const cluster of this.clusters) {
      meshes = meshes.concat(cluster.groupMesh);
    }
    return meshes;
  }

  getRackMeshes () {
    let meshes = [];
    for (const cluster of this.clusters) {
      meshes = meshes.concat(cluster.getRackMeshes());
    }
    return meshes;
  }

  getSlotMeshes() {
    let meshes = [];
    for (const cluster of this.clusters) {
      meshes = meshes.concat(cluster.getSlotMeshes());
    }
    return meshes;
  }

  getNodeMeshes() {
    let meshes = [];
    for (const cluster of this.clusters) {
      meshes = meshes.concat(cluster.getNodeMeshes());
    }
    return meshes;
  }

  getNodePanelMeshes() {
    let meshes = [];
    for (const cluster of this.clusters) {
      meshes = meshes.concat(cluster.getNodePanelMeshes());
    }
    return meshes;
  }
}

class RoomTile {

  /**
   * 
   * @param {number} indexX 
   * @param {number} indexZ 
   * @param {number} positionX 
   * @param {number} positionZ 
   */
  constructor (indexX, indexZ, positionX, positionZ) {
    /**
     * @type {number}
     */
    this.indexX = indexX;
    /**
     * @type {number}
     */
    this.indexY = indexZ;
    /**
     * @type {number}
     */
    this.positionX = positionX;
    /**
     * @type {number}
     */
    this.positionY = positionZ;
  }

}
