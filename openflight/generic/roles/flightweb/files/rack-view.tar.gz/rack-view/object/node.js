import {
  nodeMaterial,
  nodeHoveredMaterial,
  newNode1uMesh,
  nodePanel1uStatusLightOffMaterial,
  nodePanelDecorationLightBlueMaterial,
  nodePanelDecorationLightYellowMaterial,
  nodePanelDecorationLightOffMaterial,
  nodePanel1uStatusLightOnMaterial,
  newStorageNode4uMesh,
  storageNode4uStatusLightOnMaterial,
  storageNode4uStatusLightOffMaterial,
  hardDriveBayFrameMaterial,
  hardDriveBayVentsLiningMaterial,
  newLoginNode1uMesh,
  loginNode1uStatusLightOnMaterial,
  loginNode1uStatusLightOffMaterial
} from '../mesh.js'

import {
  equipmentLiftDistanceZ,
  equipmentLiftTransitionDuration,
  equipmentPulloutDistanceZ,
  equipmentPulloutTransitionDuration,
  equipmentPushinTransitionDuration,
  rackEnclosureNarrowPostWidth,
  rackInnerHeight,
  uHeight
} from '../spec.js'

const IDLE_MODE = 0;
const LIFT_MODE = 1;
const PULLOUT_MODE = 2;
const MOVE_MODE = 3;
const PUSHIN_MODE = 4;

export const RUNNING_STATUS = 'running';
export const STOPPED_STATUS = 'stopped';

const DECORATION_ON_STATUS = 0;
const DECORATION_OFF_STATUS = 1;
const DECORATION_NA_STATUS = 2;

export const nodeTypes = function () {
  return ['login', 'compute', 'storage'];
}

export const newNode = function (rack, index, id, type, uNumber, status) {
  if (type === 'compute') {
    if (uNumber === 1) {
      return new ComputeNode1u(rack, index, id, status);
    } else if (uNumber === 2) {
      // not supported yet
    } else if (uNumber === 4) {
      // not supported yet
    }
  } else if (type === 'login') {
    if (uNumber === 1) {
      return new LoginNode1u(rack, index, id, status);
    }else if (uNumber === 2) {
      // not supported yet
    }else if (uNumber === 4) {
      // not supported yet
    }
  } else if (type === 'storage') {
    if (uNumber === 1) {
      // not supported yet
    }else if (uNumber === 2) {
      // not supported yet
    }else if (uNumber === 4) {
      return new StorageNode4u(rack, index, id, status);
    }
  }
}

class Node {

  /**
   * @param {THREE.Group} groupMesh The 3d model of the node.
   * @param {Rack} rack The rack that this node belongs to.
   * @param {number} index The index indicating the position of the node in the rack.
   * @param {string} id The index indicating the position of the node in the rack.
   * @param {string} type The index indicating the position of the node in the rack.
   * @param {number} uNumber The number indicating how many slots the node occupies.
   * @param {string} status The node status.
   */
  constructor (groupMesh, rack, index, id, type, uNumber, status) {

    this.groupMesh = groupMesh;
    this.groupMesh.userData.flightObj = this;
    for (const interactiveChild of Object.values(groupMesh.userData.interactiveChildren)) {
      interactiveChild.userData.flightObj = this;
    }

    this.id = id;
    this.type = type;
    this.uNumber = uNumber;
    this.status = status;
    if (this.status === RUNNING_STATUS) {
      this.start();
    } else {
      this.shutDown();
    }
    this.addToRack(rack, index);
    rack.cluster.nodes.push(this);
    
    // transition-related attributes
    this.transitionMode = IDLE_MODE;
    this.currentTransitionDuration = 0;
    this.originalPositionX = this.groupMesh.position.x;
    this.originalPositionY = this.groupMesh.position.y;
    this.originalPositionZ = this.groupMesh.position.z;
    this.moveDistanceX = 0;
    this.moveDistanceY = 0;
    this.moveDistanceZ = 0;
    this.equipmentMoveTransitionDuration = 0;
    this.transitionCallback = undefined;

  }

  /**
   * 
   * @param {Rack} rack 
   * @param {number} index
   */
  addToRack (rack, index) {
    this.slots = [];
    for (let i = index; i < index + this.uNumber; i++) {
      const slot = rack.slots[i];
      this.slots.push(slot);
      slot.node = this;
    }
    this.groupMesh.position.x = rack.groupMesh.position.x;
    this.groupMesh.position.y = rackEnclosureNarrowPostWidth + rackInnerHeight - (index + this.uNumber / 2) * uHeight;
    this.groupMesh.position.z = rack.groupMesh.position.z;
  }

  getIndex () {
    return this.slots[0].index;
  }

  removeFromSlots() {
    for (const slot of this.slots) {
      slot.node = undefined;
    }
  }

  hover () {}

  unhover () {
    if (this.status === RUNNING_STATUS) {
      this.start();
    } else if (this.status === STOPPED_STATUS) {
      this.shutDown();
    }
  }

  start () {
    this.status = RUNNING_STATUS;
  }

  shutDown() {
    this.status = STOPPED_STATUS;
  }

  requestLift () {
    this.originalPositionZ = this.groupMesh.position.z;
    this.moveDistanceZ = this.slots[0].rack.groupMesh.position.z + equipmentLiftDistanceZ - this.originalPositionZ;
    this.currentTransitionDuration = 0;
    this.transitionMode = LIFT_MODE;
  }

  requestChangeSlot (newTopSlot, callback) {
    this.originalPositionZ = this.groupMesh.position.z;
    this.moveDistanceZ = this.slots[0].rack.groupMesh.position.z + equipmentPulloutDistanceZ - this.originalPositionZ;
    this.currentTransitionDuration = 0;
    this.transitionMode = PULLOUT_MODE;
    this.transitionCallback = callback;
    
    for (const slot of this.slots) {
      slot.node = undefined;
    }
    const newSlots = [];
    for (let i = newTopSlot.index; i < newTopSlot.index + this.uNumber; i++) {
      const slot = newTopSlot.rack.slots[i];
      newSlots.push(slot);
      slot.node = this;
    }
    this.slots = newSlots;
  }

  requestPushin (callback) {
    this.originalPositionZ = this.groupMesh.position.z;
    this.moveDistanceZ = this.originalPositionZ - this.slots[0].rack.groupMesh.position.z;
    this.currentTransitionDuration = 0;
    this.transitionMode = PUSHIN_MODE;
    this.transitionCallback = callback;
  }

  notifyNextFrame (frameDuration) {
    if (this.transitionMode === LIFT_MODE) {

      this.currentTransitionDuration += frameDuration;
      if (this.currentTransitionDuration > equipmentLiftTransitionDuration) {
        this.groupMesh.position.z = this.slots[0].rack.groupMesh.position.z + equipmentLiftDistanceZ;
        this.transitionMode = IDLE_MODE;
      } else {
        const durationProgress = this.currentTransitionDuration / equipmentLiftTransitionDuration;
        const frameProgress = 0.387 * Math.pow(durationProgress, 4) - 0.491 * Math.pow(durationProgress, 3) - 1.140 * Math.pow(durationProgress, 2) + 2.245 * durationProgress;
        this.groupMesh.position.z = this.originalPositionZ + this.moveDistanceZ * frameProgress;
      }

    } else if (this.transitionMode === PULLOUT_MODE) {

      this.currentTransitionDuration += frameDuration;
      if (this.currentTransitionDuration > equipmentPulloutTransitionDuration) {
        this.groupMesh.position.z = this.slots[0].rack.groupMesh.position.z + equipmentPulloutDistanceZ;
        
        this.originalPositionX = this.groupMesh.position.x;
        this.originalPositionY = this.groupMesh.position.y;
        this.originalPositionZ = this.groupMesh.position.z;
        this.moveDistanceX = this.slots[0].slotMesh.position.x - this.originalPositionX;
        this.moveDistanceY = rackEnclosureNarrowPostWidth + rackInnerHeight - (this.slots[0].index + this.uNumber / 2) * uHeight - this.originalPositionY;
        this.moveDistanceZ = 0;
        this.currentTransitionDuration = 0;
        this.equipmentMoveTransitionDuration = Math.max(Math.sqrt(Math.pow(this.moveDistanceX, 2) + Math.pow(this.moveDistanceY, 2)) * 0.03, 0.36);
        this.transitionMode = MOVE_MODE;
        
      } else {
        const durationProgress = this.currentTransitionDuration / equipmentPulloutTransitionDuration;
        const frameProgress = 1 - Math.pow(1 - durationProgress, 2);
        this.groupMesh.position.z = this.originalPositionZ + this.moveDistanceZ * frameProgress;
      }

    } else if (this.transitionMode === MOVE_MODE) {

      this.currentTransitionDuration += frameDuration;
      if (this.currentTransitionDuration > this.equipmentMoveTransitionDuration) {
        this.groupMesh.position.x = this.slots[0].slotMesh.position.x;
        this.groupMesh.position.y = rackEnclosureNarrowPostWidth + rackInnerHeight - (this.slots[0].index + this.uNumber / 2) * uHeight;
        
        this.originalPositionX = this.groupMesh.position.x;
        this.originalPositionY = this.groupMesh.position.y;
        this.moveDistanceX = 0;
        this.moveDistanceY = 0;
        this.moveDistanceZ = this.originalPositionZ - this.slots[0].rack.groupMesh.position.z;
        this.currentTransitionDuration = 0;
        this.equipmentMoveTransitionDuration = 0;
        this.transitionMode = PUSHIN_MODE;
      } else {
        const durationProgress = this.currentTransitionDuration / this.equipmentMoveTransitionDuration;
        const frameProgress = 1 - Math.pow(1 - durationProgress, 2);
        this.groupMesh.position.x = this.originalPositionX + this.moveDistanceX * frameProgress;
        this.groupMesh.position.y = this.originalPositionY + this.moveDistanceY * frameProgress;
      }

    } else if (this.transitionMode === PUSHIN_MODE) {

      this.currentTransitionDuration += frameDuration;
      if (this.currentTransitionDuration > equipmentPushinTransitionDuration) {
        this.groupMesh.position.z = this.slots[0].rack.groupMesh.position.z;
        this.transitionMode = IDLE_MODE;
        this.transitionCallback();
        this.transitionCallback = undefined;
      } else {
        const durationProgress = this.currentTransitionDuration / equipmentPushinTransitionDuration;
        const frameProgress = 0.387 * Math.pow(durationProgress, 4) - 0.491 * Math.pow(durationProgress, 3) - 1.140 * Math.pow(durationProgress, 2) + 2.245 * durationProgress;
        this.groupMesh.position.z = this.originalPositionZ - this.moveDistanceZ * frameProgress;
      }

    }
  }

  notifyCameraEffectFrame(_frameDuration) {}

}

class LoginNode1u extends Node{
  /**
   * @param {Rack} rack The rack that this node belongs to.
   * @param {number} index The index indicating the position of the node in the rack.
   * @param {string} id The index indicating the position of the node in the rack.
   * @param {string} status The node status.
   */
  constructor (rack, index, id, status) {
    super(newLoginNode1uMesh(), rack, index, id, 'login', 1, status);
  }

  hover () {
    for (const [key, interactiveChild] of Object.entries(this.groupMesh.userData.interactiveChildren)) {
      if (key !== 'panelCollisionMesh') {
        interactiveChild.material = nodeHoveredMaterial;
      }
    }
  }

  unhover () {
    super.unhover();

    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.panelFrameMesh.material = nodeMaterial;
    interactiveChildren.bodyMesh.material = nodeMaterial;
  }

  start () {
    super.start();

    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = loginNode1uStatusLightOnMaterial;
  }

  shutDown() {
    super.shutDown();

    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = loginNode1uStatusLightOffMaterial;
  }
}

class ComputeNode1u extends Node{
  /**
   * @param {Rack} rack The rack that this node belongs to.
   * @param {number} index The index indicating the position of the node in the rack.
   * @param {string} id The index indicating the position of the node in the rack.
   * @param {string} status The node status.
   */
  constructor (rack, index, id, status) {
    super(newNode1uMesh(), rack, index, id, 'compute', 1, status);

    this.currentDecorationLight2StatusDuration = 0;
  }

  hover () {
    this.decorationLight2Status = DECORATION_NA_STATUS;
    for (const [key, interactiveChild] of Object.entries(this.groupMesh.userData.interactiveChildren)) {
      if (key !== 'panelCollisionMesh') {
        interactiveChild.material = nodeHoveredMaterial;
      }
    }
  }

  unhover () {
    super.unhover();

    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.panelFrameMesh.material = nodeMaterial;
    interactiveChildren.bodyMesh.material = nodeMaterial;
  }

  start () {
    super.start();

    this.decorationLight2Status = DECORATION_ON_STATUS;
    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = nodePanel1uStatusLightOnMaterial;
    interactiveChildren.decorationLight1Mesh.material = nodePanelDecorationLightBlueMaterial;
    interactiveChildren.decorationLight2Mesh.material = nodePanelDecorationLightYellowMaterial;
    interactiveChildren.decorationLight3Mesh.material = nodePanelDecorationLightYellowMaterial;
    interactiveChildren.decorationLight4Mesh.material = nodePanelDecorationLightBlueMaterial;
    interactiveChildren.decorationLight5Mesh.material = nodePanelDecorationLightYellowMaterial;
  }

  shutDown() {
    super.shutDown();

    this.decorationLight2Status = DECORATION_NA_STATUS;
    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = nodePanel1uStatusLightOffMaterial;
    interactiveChildren.decorationLight1Mesh.material = nodePanelDecorationLightOffMaterial;
    interactiveChildren.decorationLight2Mesh.material = nodePanelDecorationLightOffMaterial;
    interactiveChildren.decorationLight3Mesh.material = nodePanelDecorationLightOffMaterial;
    interactiveChildren.decorationLight4Mesh.material = nodePanelDecorationLightOffMaterial;
    interactiveChildren.decorationLight5Mesh.material = nodePanelDecorationLightOffMaterial;
  }

  notifyCameraEffectFrame(frameDuration) {
    this.currentDecorationLight2StatusDuration += frameDuration;
    if (this.decorationLight2Status === DECORATION_ON_STATUS && Math.random() < (this.currentDecorationLight2StatusDuration - 0.036) / 1.2) {
      this.currentDecorationLight2StatusDuration = 0;
      this.decorationLight2Status = DECORATION_OFF_STATUS;
      this.groupMesh.userData.interactiveChildren.decorationLight2Mesh.material = nodePanelDecorationLightOffMaterial;
    } else if (this.decorationLight2Status === DECORATION_OFF_STATUS && Math.random() < (this.currentDecorationLight2StatusDuration - 0.024) / 0.072) {
      this.currentDecorationLight2StatusDuration = 0;
      this.decorationLight2Status = DECORATION_ON_STATUS;
      this.groupMesh.userData.interactiveChildren.decorationLight2Mesh.material = nodePanelDecorationLightYellowMaterial;
    }
  }
}

class StorageNode4u extends Node{
  /**
   * @param {Rack} rack The rack that this node belongs to.
   * @param {number} index The index indicating the position of the node in the rack.
   * @param {string} id The index indicating the position of the node in the rack.
   * @param {string} status The node status.
   */
  constructor (rack, index, id, status) {
    super(newStorageNode4uMesh(), rack, index, id, 'storage', 4, status);
    
    this.currentDecorationLightStatusDuration = 0;
    this.currentOffDecorationLightIndex = undefined;
  }

  hover () {
    this.decorationLightStatus = DECORATION_NA_STATUS;
    for (const [key, interactiveChild] of Object.entries(this.groupMesh.userData.interactiveChildren)) {
      if (key !== 'panelCollisionMesh') {
        interactiveChild.material = nodeHoveredMaterial;
      }
    }
  }
  
  unhover () {
    super.unhover();

    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    for (const [key, interactiveChild] of Object.entries(interactiveChildren)) {
      if (key === 'panelFrameMesh' || key === 'bodyMesh') {
        interactiveChild.material = nodeMaterial;
      } else if (key.startsWith('hardDriveBayFrameMesh')) {
        interactiveChild.material = hardDriveBayFrameMaterial;
      } else if (key.startsWith('hardDriveBayVentsLiningMesh')) {
        interactiveChild.material = hardDriveBayVentsLiningMaterial;
      }
    }

  }

  start () {
    super.start();

    this.decorationLightStatus = DECORATION_ON_STATUS;
    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = storageNode4uStatusLightOnMaterial;
    for (const [key, interactiveChild] of Object.entries(interactiveChildren)) {
      if (key.startsWith('decorationLightMesh')) {
        if ([0, 2, 6, 7, 8, 11, 12, 14, 15, 18].includes(parseInt(key.slice('decorationLightMesh'.length)))) {
          interactiveChild.material = nodePanelDecorationLightYellowMaterial;
        } else {
          interactiveChild.material = nodePanelDecorationLightBlueMaterial;
        }
      }
    }
  }

  shutDown () {
    super.shutDown();

    this.decorationLightStatus = DECORATION_NA_STATUS;
    const interactiveChildren = this.groupMesh.userData.interactiveChildren;
    interactiveChildren.statusLightMesh.material = storageNode4uStatusLightOffMaterial;
    for (const [key, interactiveChild] of Object.entries(interactiveChildren)) {
      if (key.startsWith('decorationLightMesh')) {
        interactiveChild.material = nodePanelDecorationLightOffMaterial;
      }
    }
  }

  notifyCameraEffectFrame(frameDuration) {
    this.currentDecorationLightStatusDuration += frameDuration;
    if (this.decorationLightStatus === DECORATION_ON_STATUS && Math.random() < (this.currentDecorationLightStatusDuration - 0.036) / 1.2) {
      this.currentDecorationLightStatusDuration = 0;
      this.currentOffDecorationLightIndex = Math.floor(Math.random() * 20);
      this.decorationLightStatus = DECORATION_OFF_STATUS;
      this.groupMesh.userData.interactiveChildren[`decorationLightMesh${this.currentOffDecorationLightIndex}`].material = nodePanelDecorationLightOffMaterial;
    } else if (this.decorationLightStatus === DECORATION_OFF_STATUS && Math.random() < (this.currentDecorationLightStatusDuration - 0.024) / 0.12) {
      this.currentDecorationLightStatusDuration = 0;
      this.decorationLightStatus = DECORATION_ON_STATUS;
      if ([0, 2, 6, 7, 8, 11, 12, 14, 15, 18].includes(this.currentOffDecorationLightIndex)) {
        this.groupMesh.userData.interactiveChildren[`decorationLightMesh${this.currentOffDecorationLightIndex}`].material = nodePanelDecorationLightYellowMaterial;
      } else {
        this.groupMesh.userData.interactiveChildren[`decorationLightMesh${this.currentOffDecorationLightIndex}`].material = nodePanelDecorationLightBlueMaterial;
      }
      this.currentOffDecorationLightIndex = undefined;
    }
  }
}