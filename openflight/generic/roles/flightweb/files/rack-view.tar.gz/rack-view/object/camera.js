import * as THREE from '../three.module.min.js'
import {
  cameraFOV,
  defaultCameraPositionY,
  cameraVerticalPanRange,
  cameraPanTransitionDuration,
  cameraViewDistanceZ,
  wideRackOuterWidth,
  halfWideRackOuterWidth,
  halfRackOuterDepth
} from '../spec.js'

export const TOP_DOWN_MODE = 0;
export const STREET_MODE = 1;
/**
 * 
 * @returns {Camera}
 */
export const newCamera = function (viewportDimensions, mode, focusingCluster) {
  return new Camera(viewportDimensions, mode, focusingCluster);
}

class Camera {

  /**
   * @param {DOMRect} viewportDimensions The dimensions of the scene.
   * @param {number} mode The camera mode.
   * @param {Cluster} focusingCluster The focusing cluster. Only applicable on street mode.
   */
  constructor (viewportDimensions, mode, focusingCluster) {
    this.camera = new THREE.PerspectiveCamera(cameraFOV, viewportDimensions.width / viewportDimensions.height, 0.1, 1000);
    this.mode = mode;
    this.focusingCluster = focusingCluster;
    // TODO top down mode has not been practically designed and implemented yet
    if (mode === TOP_DOWN_MODE) {
      this.camera.position.y = 180;
      this.camera.lookAt(0, 0, 0);
    } else if (mode === STREET_MODE) {
      this.camera.position.y = defaultCameraPositionY;
      this.camera.position.z = halfRackOuterDepth / 2 + cameraViewDistanceZ;
      if (focusingCluster !== undefined) {
        this.updateFocusingCluster(focusingCluster);
      }
    }

    // transition-related attributes
    this.panTransitionIdle = true;
    this.currentPanTransitionDuration = 0;
    this.originHorizontalPan = this.defaultPositionX;
    this.targetHorizontalPan = this.defaultPositionX;
    this.horizontalPanDistance = 0;
    this.originVerticalPan = defaultCameraPositionY;
    this.targetVerticalPan = defaultCameraPositionY;
    this.verticalPanDistance = 0;
  }

  /**
   * 
   * @param {Cluster} cluster 
   */
  updateFocusingCluster (cluster) {
    if (this.mode === STREET_MODE) {
      if (cluster !== undefined) {
        this.focusingCluster = cluster;
      }
      this.defaultPositionX = this.focusingCluster.groupMesh.position.x + this.focusingCluster.getWidth() / 2 - halfWideRackOuterWidth;
      this.camera.position.x = this.defaultPositionX;
      this.camera.position.z = this.focusingCluster.groupMesh.position.z + halfRackOuterDepth / 2 + cameraViewDistanceZ;
    }
  }

  requestPan (e) {
    if (this.mode === STREET_MODE && this.focusingCluster !== undefined) {
      const viewportDimensions = e.target.getBoundingClientRect();
      // this pan has a range from the center of the cluster to the leftmost or the rightmost of the cluster plus 1.5 times rack width on each side
      const cameraHorizontalPanRange = this.focusingCluster.getWidth() / 2 + wideRackOuterWidth * 1.5 - cameraViewDistanceZ * Math.tan(cameraFOV * Math.PI / 360) * viewportDimensions.width / viewportDimensions.height;
      
      this.originHorizontalPan = this.camera.position.x;
      this.targetHorizontalPan = this.defaultPositionX + (e.clientX - viewportDimensions.left) / viewportDimensions.width * 2 * cameraHorizontalPanRange - cameraHorizontalPanRange;
      this.horizontalPanDistance = this.targetHorizontalPan - this.originHorizontalPan;

      this.originVerticalPan = this.camera.position.y;
      this.targetVerticalPan= defaultCameraPositionY + cameraVerticalPanRange - (e.clientY - viewportDimensions.top) / viewportDimensions.height * 2 * cameraVerticalPanRange;
      this.verticalPanDistance = this.targetVerticalPan - this.originVerticalPan;
      
      this.currentPanTransitionDuration = 0;
      this.panTransitionIdle = false;
    }
  }

  requestRestoration () {
    if (this.mode === STREET_MODE && this.focusingCluster !== undefined) {
      
      this.originHorizontalPan = this.camera.position.x;
      this.targetHorizontalPan = this.defaultPositionX;
      this.horizontalPanDistance = this.targetHorizontalPan - this.originHorizontalPan;

      this.originVerticalPan = this.camera.position.y;
      this.targetVerticalPan= defaultCameraPositionY;
      this.verticalPanDistance = this.targetVerticalPan - this.originVerticalPan;
      
      this.currentPanTransitionDuration = 0;
      this.panTransitionIdle = false;
    }
  }

  notifyNextFrame (frameDuration) {
    if (!this.panTransitionIdle) {
      this.currentPanTransitionDuration += frameDuration;
      if (this.currentPanTransitionDuration > cameraPanTransitionDuration) {
        this.camera.position.x = this.targetHorizontalPan;
        this.camera.position.y = this.targetVerticalPan;
        this.panTransitionIdle = true;
      } else {
        const durationProgress = this.currentPanTransitionDuration / cameraPanTransitionDuration;
        // animation easing formula
        const frameProgress = 0.387 * Math.pow(durationProgress, 4) - 0.491 * Math.pow(durationProgress, 3) - 1.140 * Math.pow(durationProgress, 2) + 2.245 * durationProgress;
        this.camera.position.x = this.originHorizontalPan + frameProgress * this.horizontalPanDistance;
        this.camera.position.y = this.originVerticalPan + frameProgress * this.verticalPanDistance;
      }
    }
    if (this.mode === STREET_MODE && this.focusingCluster !== undefined) {
      for (const node of this.focusingCluster.getNodes()) {
        node.notifyCameraEffectFrame(frameDuration);
      }
    }
  }

}

