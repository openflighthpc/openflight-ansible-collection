import * as THREE from '../three.module.min.js'

import {
  newSingleRackMesh,
  newLeftRackMesh,
  newMiddleRackMesh,
  newRightRackMesh
} from '../mesh.js'

import {
  wideRackOuterWidth
} from '../spec.js'

import {
  newSlot
} from '../object.js'

export const newRack = function (cluster) {
  return new Rack(cluster);
}

export const slotsPerRack = function() {
  return Rack.slotsPerRack;
}

class Rack {

  static slotsPerRack = 42;

  /**
   * 
   * @param {Cluster} cluster The cluster that this rack belongs to.
   */
  constructor(cluster) {

    const groupMesh = new THREE.Group();
    groupMesh.userData.flightObj = this;
    this.uCapacity = 42;
    this.groupMesh = groupMesh;
    /**
     * @type {Slot[]}
     */
    this.slots = [];
    this.addToCluster(cluster);
    for (let i = 0; i < this.uCapacity; i++) {
      newSlot(this, i);
    }
  }

  /**
   * 
   * @param {Cluster} cluster 
   */
  addToCluster (cluster) {
    this.index = cluster.racks.length;
    this.cluster = cluster;
    if (this.index === 0) {
      this.frameMesh = newSingleRackMesh();
    } else if (this.index === 1) {
      const leftRack = cluster.racks[this.index - 1];
      leftRack.groupMesh.remove(leftRack.frameMesh);
      leftRack.frameMesh = newLeftRackMesh();
      leftRack.groupMesh.add(leftRack.frameMesh);
      this.frameMesh = newRightRackMesh();
    } else if (this.index > 1) {
      const leftRack = cluster.racks[this.index - 1];
      leftRack.groupMesh.remove(leftRack.frameMesh);
      leftRack.frameMesh = newMiddleRackMesh();
      leftRack.groupMesh.add(leftRack.frameMesh);
      this.frameMesh = newRightRackMesh();
    }
    this.groupMesh.add(this.frameMesh);
    this.groupMesh.position.x = cluster.groupMesh.position.x + this.index * wideRackOuterWidth;
    this.groupMesh.position.z = cluster.groupMesh.position.z;

    cluster.racks.push(this);
  }

  getSlotMeshes() {
    let meshes = [];
    for (const slot of this.slots) {
      meshes.push(slot.slotMesh);
    }
    return meshes;
  }

  getNodes () {
    let nodes = [];
    for (const slot of this.slots) {
      if (slot.node !== undefined) {
        nodes.push(slot.node);
      }
    }
    return nodes;
  }

  getNodeMeshes () {
    let meshes = [];
    for (const slot of this.slots) {
      if (slot.node !== undefined) {
        meshes.push(slot.node.groupMesh);
      }
    }
    return meshes;
  }

  getNodePanelMeshes() {
    let meshes = [];
    for (const slot of this.slots) {
      if (slot.node !== undefined) {
        meshes.push(slot.node.groupMesh.userData.interactiveChildren.panelCollisionMesh);
      }
    }
    return meshes;
  }

}

