import * as THREE from '../three.module.min.js'

import {
  slotMaterial,
  slotAvailableMaterial,
  slotOccupiedMaterial,
  newSlotMesh
} from '../mesh.js'
import {
  rackEnclosureNarrowPostWidth,
  rackInnerHeight,
  slotDistanceZ,
  uHeight,
  halfUHeight,
  halfEquipmentBodyDepth,
  equipmentPanelDepth
} from '../spec.js'

export const newSlot = function (rack, index) {
  return new Slot(rack, index);
}

class Slot {
  /**
   * @param {Rack} rack The rack that this slot belongs to.
   * @param {number} index The index indicating the position of the slot in the rack.
   */
  constructor(rack, index) {
    const slotMesh = newSlotMesh();
    slotMesh.userData.flightObj = this;

    this.slotMesh = slotMesh;
    this.index = index;
    this.node = undefined;
    this.addToRack(rack);
  }

  /**
   * 
   * @param {Rack} rack 
   */
  addToRack(rack) {
    this.rack = rack;
    this.slotMesh.position.x = rack.groupMesh.position.x;
    this.slotMesh.position.y = rackEnclosureNarrowPostWidth + rackInnerHeight - halfUHeight - this.index * uHeight;
    this.slotMesh.position.z = rack.groupMesh.position.z + halfEquipmentBodyDepth + equipmentPanelDepth + slotDistanceZ;

    this.rack.slots.push(this);
  }

  hover (available) {
    if (available) {
      this.slotMesh.material = slotAvailableMaterial;
    } else {
      this.slotMesh.material = slotOccupiedMaterial;
    }
  }

  unhover () {
    this.slotMesh.material = slotMaterial;
  }
}

