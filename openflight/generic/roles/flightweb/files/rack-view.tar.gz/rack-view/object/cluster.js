import * as THREE from '../three.module.min.js'

import {
  wideRackOuterWidth
} from '../spec.js'
import {newRack} from "../object.js";

/**
   * 
   * @param {Room} room The room that this cluster belongs to.
   * @param {string} id 
   * @param {number} tileIndexX 
   * @param {number} tileIndexZ
   * @returns {Cluster}
   */
export const newCluster = function (room, id, tileIndexX, tileIndexY) {
  return new Cluster(room, id, tileIndexX, tileIndexY);
}

class Cluster {

  /**
   * 
   * @param {Room} room The room that this cluster belongs to.
   * @param {string} id 
   * @param {number} tileIndexX
   * @param {number} tileIndexZ 
   */
  constructor(room, id, tileIndexX, tileIndexZ) {
    const groupMesh = new THREE.Group();
    groupMesh.userData.flightObj = this;

    this.id = id;
    this.groupMesh = groupMesh;
    /**
     * @type {Rack[]}
     */
    this.racks = [];
    this.tileIndexX = tileIndexX;
    this.tileIndexZ = tileIndexZ;
    this.nodes = [];
    this.addToRoom(room);
  }

  addToRoom (room) {
    this.room = room;
    this.groupMesh.position.x = room.tiles[this.tileIndexX][this.tileIndexZ].positionX;
    this.groupMesh.position.z = room.tiles[this.tileIndexX][this.tileIndexZ].positionY;
    
    room.clusters.push(this);
  }

  getRackMeshes () {
    let meshes = [];
    for (const rack of this.racks) {
      meshes = meshes.concat(rack.groupMesh);
    }
    return meshes;
  }

  getSlotMeshes() {
    let meshes = [];
    for (const rack of this.racks) {
      meshes = meshes.concat(rack.getSlotMeshes());
    }
    return meshes;
  }

  getNodes() {
    let nodes = [];
    for (const rack of this.racks) {
      nodes = nodes.concat(rack.getNodes());
    }
    return nodes;
  }

  getNodeMeshes() {
    let meshes = [];
    for (const rack of this.racks) {
      meshes = meshes.concat(rack.getNodeMeshes());
    }
    return meshes;
  }

  getNodePanelMeshes() {
    let meshes = [];
    for (const rack of this.racks) {
      meshes = meshes.concat(rack.getNodePanelMeshes());
    }
    return meshes;
  }

  getWidth() {
    return this.racks.length * wideRackOuterWidth;
  }

  getGroupedNodes() {
    return Object.groupBy(this.nodes, ({ type }) => type);
  }

  removeNode(node) {
    this.nodes.splice(this.nodes.indexOf(node), 1);
  }

  generateUniqueNodeId(type) {
    let nodeId = 0;
    if (this.getGroupedNodes()[type] !== undefined) {
      const nodeIds = this.getGroupedNodes()[type]
        .map((node) => Number(node.id.replace(type, '')))
        .sort(function (a, b) { return a - b });
      nodeId = nodeIds[nodeIds.length - 1] + 1;
    }
    return nodeId;
  }

  firstEmptySlot(uNumber) {
    for (const rack of this.racks) {
      for (let i = 0; i < (rack.slots.length - uNumber + 1); i++) {
        const slotRange = rack.slots.slice(i, i + uNumber);
        const nodes = slotRange.map((slot) => slot.node);
        if (nodes.every((node) => node === undefined)) {
          return rack.slots[i];
        }
      }
    }
  }

  hasEmptySlot(uNumber) {
    return this.firstEmptySlot(uNumber) !== undefined;
  }

  canFitNewRack() {
    return this.tileIndexX + this.racks.length < this.room.horizontalTileNumber;
  }
}
