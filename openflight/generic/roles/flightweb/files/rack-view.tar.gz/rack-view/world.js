import * as ThreeScene from './scene.js'
import * as ThreeController from './controller.js'


import {
  ThreeCamera,
  ThreeCameraRaycaster,
  newRoom,
  newCluster,
  newRack,
  ThreeNode,
  newNodeList,
  slotsPerRack,
} from './object.js'

export const IDLE_STATUS = 0;
export const GRABBING_STATUS = 1;
export const PUTTING_STATUS = 2;
export const newWorldFromStorage = function (data) {
  return new World(data);
};

export const newWorldFromJSON = function (data) {
  let maxNumRacks = 0;
  let clusterPosition = 1;

  data.clusters.map((cluster) => {
    const nodes = cluster['nodes'];
    let numNodes = 0;
    const groupedNodes = Object.groupBy(nodes, ({ type }) => type);
    let nodesInfo = [];
    for (const type of ThreeNode.nodeTypes()) {
      const typedNodes = groupedNodes[type];
      if (typedNodes !== undefined) {
        typedNodes.map((node) => {
          node.id = type + typedNodes.indexOf(node);
          node.status = typedNodes[typedNodes.indexOf(node)].status ??= ThreeNode.RUNNING_STATUS;
          if (type === 'compute' || type === 'login' || type === 'gateway') {
            node.uNumber = node.uNumber === undefined? 1 : node.uNumber;
          }else if (type ==='storage') {
            node.uNumber = node.uNumber === undefined? 4 : node.uNumber;
          }
          numNodes += node.uNumber;
        })
        nodesInfo.push(...typedNodes);
      }
    }
    const numRacks = Math.ceil(numNodes/slotsPerRack());
    maxNumRacks = Math.max(numRacks, maxNumRacks);
    cluster.racks = new Array(numRacks);
    let rackIndex = 0;
    let nodeIndex = 0;
    while (nodesInfo.length > 0) {
      if (nodeIndex === 0) {
        cluster.racks[rackIndex] = {'nodes': []};
      }
      const nodeInfo = nodesInfo.shift();
      nodeInfo.index = nodeIndex;
      cluster.racks[rackIndex].nodes.push(nodeInfo);
      nodeIndex += nodeInfo.uNumber;
      if (nodeIndex >= slotsPerRack()) {
        nodeIndex = 0;
        rackIndex += 1;
      }
    }

    cluster.tileIndex = {
      x: 1,
      z: clusterPosition
    };
    clusterPosition += 2;
  })

  data.roomSize = {
    horizontalTileNumber: Math.max(maxNumRacks + 2, 10),
    verticalTileNumber: Math.max(data.clusters.length * 2, 10)
  };

  return new World(data);
};

class World {

  constructor (data) {
    this.domRoomWrapper = globalThis.document.getElementById('room-wrapper');
    this.domRoom = globalThis.document.getElementById('room');
    const viewportDimensions = this.domRoomWrapper.getBoundingClientRect();
    this.room = newRoom(data.roomSize.horizontalTileNumber, data.roomSize.verticalTileNumber);
    for (const cluster of data.clusters) {
      const c = newCluster(this.room, cluster.id, cluster.tileIndex.x, cluster.tileIndex.z);
      for (const rack of cluster.racks) {
        const r = newRack(c);
        for (const node of rack.nodes) {
          const _n = ThreeNode.newNode(r, node.index, node.id, node.type, node.uNumber, node.status);
        }
      }
    }

    this.camera = ThreeCamera.newCamera(viewportDimensions, ThreeCamera.STREET_MODE, this.room.clusters[0]);
    this.raycaster = ThreeCameraRaycaster.newCameraRaycaster(this.camera);
    
    this.scene = ThreeScene.newScene(this);
    this.controller = ThreeController.newController(this);

    this.domSideMenu = globalThis.document.getElementById('menu-wrapper');
    this.domSideMenu.getElementsByClassName('menu-title')[0].innerHTML = this.room.clusters[0].id;
    this.sideMenu = newNodeList(this.room.clusters[0], this);

    this.status = IDLE_STATUS;
    this.hoveringNode = undefined;
    this.grabbingNode = undefined;
    this.hoveringSlots = [];
  }
  
  getRoomMeshes () {
    return this.room.groupMesh;
  }

  getClusterMeshes () {
    return this.room.getClusterMeshes();
  }

  getRackMeshes () {
    return this.room.getRackMeshes();
  }

  getSlotMeshes() {
    return this.room.getSlotMeshes();
  }

  getNodeMeshes() {
    return this.room.getNodeMeshes();
  }

  getNodePanelMeshes() {
    return this.room.getNodePanelMeshes();
  }

  toDataJSON () {
    const data = {
      "roomSize": {
        "horizontalTileNumber": this.room.horizontalTileNumber,
        "verticalTileNumber": this.room.verticalTileNumber,
      },
      "clusters": this.room.clusters.map((cluster) => {
        const { id, tileIndexX, tileIndexZ, racks } = cluster;
        return {
          id,
          "tileIndex": {
            "x": tileIndexX,
            "z": tileIndexZ
          },
          "racks": racks.map((rack) => {
            const { slots } = rack;
            return {
              "nodes": slots.filter(slot => slot.node !== undefined && slot === slot.node.slots[0]).map((slot) => {
                const { id, type, uNumber, status } = slot.node;
                return {
                  "index": slot.node.getIndex(),
                  id,
                  type,
                  uNumber,
                  status
                };
              })
            }
          })
        };
      })
    };
    return JSON.stringify(data);
  }

  saveToLocalStorage () {
    localStorage.setItem('concertim-resources', this.toDataJSON());
  }
}
