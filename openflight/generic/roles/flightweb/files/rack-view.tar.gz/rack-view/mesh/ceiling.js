import * as THREE from '../three.module.min.js'

import {
  floorTileWidth,
  floorTileDepth,
  halfFloorTileWidth,
  halfFloorTileDepth,
  roomHeight
} from '../spec.js'

import {
    newCeilingTexture,
    newCeilingRoughnessTexture,
    newCeilingMetalnessTexture
} from './three_texture.js'

// ceiling base
//// ceiling base geometry
const newCeilingBaseGeometry = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  return new THREE.PlaneGeometry((roomHorizontalTileNumber + 3) * floorTileWidth, (roomVerticalTileNumber + 3) * floorTileDepth);
}

//// ceiling base material
const newCeilingBaseMaterial = function (roomHorizontalTileNumber, roomVerticalTileNumber) {

  const ceilingBaseMaterial = new THREE.MeshStandardMaterial({
    'color': 0xFFFFFF
  });
  ceilingBaseMaterial.roughness = 1;
  ceilingBaseMaterial.metalness = 0.72;
  ceilingBaseMaterial.flatShading = true;
  ceilingBaseMaterial.map = newCeilingTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  ceilingBaseMaterial.roughnessMap = newCeilingRoughnessTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  ceilingBaseMaterial.metalnessMap = newCeilingMetalnessTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  return ceilingBaseMaterial;
}

//// ceiling base mesh
const newCeilingBaseMesh = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const mesh = new THREE.Mesh(
    newCeilingBaseGeometry(roomHorizontalTileNumber, roomVerticalTileNumber),
    newCeilingBaseMaterial(roomHorizontalTileNumber, roomVerticalTileNumber)
  );
  mesh.rotation.x = Math.PI / 2;
  return mesh;
}

// ceiling grid
// ceiling grid shape for constructing the geometry
const newCeilingGridShape = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const halfRoomWidth = (roomHorizontalTileNumber + 3) * halfFloorTileWidth;
  const halfRoomDepth = (roomVerticalTileNumber + 3) * halfFloorTileDepth;
  const ceilingGridShape = new THREE.Shape();
  ceilingGridShape.moveTo(halfRoomWidth, halfRoomDepth);
  ceilingGridShape.lineTo(halfRoomWidth, -1 * halfRoomDepth);
  ceilingGridShape.lineTo(-1 * halfRoomWidth, -1 * halfRoomDepth);
  ceilingGridShape.lineTo(-1 * halfRoomWidth, halfRoomDepth);

  let holes = [];

  // light holes
  for (let z = 0; z - 9.6 < halfRoomDepth; z += 24.48) {
    for (let x = 0; x - 2.4 < halfRoomWidth; x += 24.48) {
      const lightHoleLeft = Math.max(x - 2.4, -1 * halfRoomWidth);
      const lightHoleRight = Math.min(x + 2.4, halfRoomWidth);
      const lightHoleFore = Math.min(z + 9.6, halfRoomDepth);
      const lightHoleBack = Math.max(z - 9.6, -1 * halfRoomDepth);

      const quadrantALightHole = new THREE.Path();
      quadrantALightHole.moveTo(lightHoleLeft, lightHoleFore);
      quadrantALightHole.lineTo(lightHoleRight, lightHoleFore);
      quadrantALightHole.lineTo(lightHoleRight, lightHoleBack);
      quadrantALightHole.lineTo(lightHoleLeft, lightHoleBack);
      holes.push(quadrantALightHole);

      if (x !== 0) {
        const quadrantBLightHole = new THREE.Path();
        quadrantBLightHole.moveTo(-1 * lightHoleLeft, lightHoleFore);
        quadrantBLightHole.lineTo(-1 * lightHoleRight, lightHoleFore);
        quadrantBLightHole.lineTo(-1 * lightHoleRight, lightHoleBack);
        quadrantBLightHole.lineTo(-1 * lightHoleLeft, lightHoleBack);
        holes.push(quadrantBLightHole);
      }

      if (z !== 0) {
        const quadrantCLightHole = new THREE.Path();
        quadrantCLightHole.moveTo(lightHoleLeft, -1 * lightHoleFore);
        quadrantCLightHole.lineTo(lightHoleRight, -1 * lightHoleFore);
        quadrantCLightHole.lineTo(lightHoleRight, -1 * lightHoleBack);
        quadrantCLightHole.lineTo(lightHoleLeft, -1 * lightHoleBack);
        holes.push(quadrantCLightHole);
      }

      if (x !==0 && z !== 0) {
        const quadrantDLightHole = new THREE.Path();
        quadrantDLightHole.moveTo(-1 * lightHoleLeft, -1 * lightHoleFore);
        quadrantDLightHole.lineTo(-1 * lightHoleRight, -1 * lightHoleFore);
        quadrantDLightHole.lineTo(-1 * lightHoleRight, -1 * lightHoleBack);
        quadrantDLightHole.lineTo(-1 * lightHoleLeft, -1 * lightHoleBack);
        holes.push(quadrantDLightHole);
      }
    }
  }

  // aluminum suspended tile holes
  for (let z = 0; z - 9.6 < halfRoomDepth; z += 24.48) {
    for (let x = 12.24; x - 9.6 < halfRoomWidth; x += 24.48) {
      const tileHoleLeft = Math.max(x - 9.6, -1 * halfRoomWidth);
      const tileHoleRight = Math.min(x + 9.6, halfRoomWidth);
      const tileHoleFore = Math.min(z + 9.6, halfRoomDepth);
      const tileHoleBack = Math.max(z - 9.6, -1 * halfRoomDepth);

      const quadrantATileHole = new THREE.Path();
      quadrantATileHole.moveTo(tileHoleLeft, tileHoleFore);
      quadrantATileHole.lineTo(tileHoleRight, tileHoleFore);
      quadrantATileHole.lineTo(tileHoleRight, tileHoleBack);
      quadrantATileHole.lineTo(tileHoleLeft, tileHoleBack);
      holes.push(quadrantATileHole);

      if (x !== 0) {
        const quadrantBTileHole = new THREE.Path();
        quadrantBTileHole.moveTo(-1 * tileHoleLeft, tileHoleFore);
        quadrantBTileHole.lineTo(-1 * tileHoleRight, tileHoleFore);
        quadrantBTileHole.lineTo(-1 * tileHoleRight, tileHoleBack);
        quadrantBTileHole.lineTo(-1 * tileHoleLeft, tileHoleBack);
        holes.push(quadrantBTileHole);
      }

      if (z !== 0) {
        const quadrantCTileHole = new THREE.Path();
        quadrantCTileHole.moveTo(tileHoleLeft, -1 * tileHoleFore);
        quadrantCTileHole.lineTo(tileHoleRight, -1 * tileHoleFore);
        quadrantCTileHole.lineTo(tileHoleRight, -1 * tileHoleBack);
        quadrantCTileHole.lineTo(tileHoleLeft, -1 * tileHoleBack);
        holes.push(quadrantCTileHole);
      }

      if (x !==0 && z !== 0) {
        const quadrantDTileHole = new THREE.Path();
        quadrantDTileHole.moveTo(-1 * tileHoleLeft, -1 * tileHoleFore);
        quadrantDTileHole.lineTo(-1 * tileHoleRight, -1 * tileHoleFore);
        quadrantDTileHole.lineTo(-1 * tileHoleRight, -1 * tileHoleBack);
        quadrantDTileHole.lineTo(-1 * tileHoleLeft, -1 * tileHoleBack);
        holes.push(quadrantDTileHole);
      }
    }
  }

  // exhaust holes
  for (let z = 12.24; z - 2.4 < halfRoomDepth; z += 24.48) {
    for (let x = 0; x - 2.4 < halfRoomWidth; x += 24.48) {
      const exhaustHoleLeft = Math.max(x - 2.4, -1 * halfRoomWidth);
      const exhaustHoleRight = Math.min(x + 2.4, halfRoomWidth);
      const exhaustHoleFore = Math.min(z + 2.4, halfRoomDepth);
      const exhaustHoleBack = Math.max(z - 2.4, -1 * halfRoomDepth);

      const quadrantAExhaustHole = new THREE.Path();
      quadrantAExhaustHole.moveTo(exhaustHoleLeft, exhaustHoleFore);
      quadrantAExhaustHole.lineTo(exhaustHoleRight, exhaustHoleFore);
      quadrantAExhaustHole.lineTo(exhaustHoleRight, exhaustHoleBack);
      quadrantAExhaustHole.lineTo(exhaustHoleLeft, exhaustHoleBack);
      holes.push(quadrantAExhaustHole);

      if (x !== 0) {
        const quadrantBExhaustHole = new THREE.Path();
        quadrantBExhaustHole.moveTo(-1 * exhaustHoleLeft, exhaustHoleFore);
        quadrantBExhaustHole.lineTo(-1 * exhaustHoleRight, exhaustHoleFore);
        quadrantBExhaustHole.lineTo(-1 * exhaustHoleRight, exhaustHoleBack);
        quadrantBExhaustHole.lineTo(-1 * exhaustHoleLeft, exhaustHoleBack);
        holes.push(quadrantBExhaustHole);
      }

      if (z !== 0) {
        const quadrantCExhaustHole = new THREE.Path();
        quadrantCExhaustHole.moveTo(exhaustHoleLeft, -1 * exhaustHoleFore);
        quadrantCExhaustHole.lineTo(exhaustHoleRight, -1 * exhaustHoleFore);
        quadrantCExhaustHole.lineTo(exhaustHoleRight, -1 * exhaustHoleBack);
        quadrantCExhaustHole.lineTo(exhaustHoleLeft, -1 * exhaustHoleBack);
        holes.push(quadrantCExhaustHole);
      }

      if (x !==0 && z !== 0) {
        const quadrantDExhaustHole = new THREE.Path();
        quadrantDExhaustHole.moveTo(-1 * exhaustHoleLeft, -1 * exhaustHoleFore);
        quadrantDExhaustHole.lineTo(-1 * exhaustHoleRight, -1 * exhaustHoleFore);
        quadrantDExhaustHole.lineTo(-1 * exhaustHoleRight, -1 * exhaustHoleBack);
        quadrantDExhaustHole.lineTo(-1 * exhaustHoleLeft, -1 * exhaustHoleBack);
        holes.push(quadrantDExhaustHole);
      }
    }
  }

  // connection holes
  for (let z = 12.24; z - 2.4 < halfRoomDepth; z += 24.48) {
    for (let x = 12.24; x - 9.6 < halfRoomWidth; x += 24.48) {
      const connectionHoleLeft = Math.max(x - 9.6, -1 * halfRoomWidth);
      const connectionHoleRight = Math.min(x + 9.6, halfRoomWidth);
      const connectionHoleFore = Math.min(z + 2.4, halfRoomDepth);
      const connectionHoleBack = Math.max(z - 2.4, -1 * halfRoomDepth);

      const quadrantAConnectionHole = new THREE.Path();
      quadrantAConnectionHole.moveTo(connectionHoleLeft, connectionHoleFore);
      quadrantAConnectionHole.lineTo(connectionHoleRight, connectionHoleFore);
      quadrantAConnectionHole.lineTo(connectionHoleRight, connectionHoleBack);
      quadrantAConnectionHole.lineTo(connectionHoleLeft, connectionHoleBack);
      holes.push(quadrantAConnectionHole);

      if (x !== 0) {
        const quadrantBConnectionHole = new THREE.Path();
        quadrantBConnectionHole.moveTo(-1 * connectionHoleLeft, connectionHoleFore);
        quadrantBConnectionHole.lineTo(-1 * connectionHoleRight, connectionHoleFore);
        quadrantBConnectionHole.lineTo(-1 * connectionHoleRight, connectionHoleBack);
        quadrantBConnectionHole.lineTo(-1 * connectionHoleLeft, connectionHoleBack);
        holes.push(quadrantBConnectionHole);
      }

      if (z !== 0) {
        const quadrantCConnectionHole = new THREE.Path();
        quadrantCConnectionHole.moveTo(connectionHoleLeft, -1 * connectionHoleFore);
        quadrantCConnectionHole.lineTo(connectionHoleRight, -1 * connectionHoleFore);
        quadrantCConnectionHole.lineTo(connectionHoleRight, -1 * connectionHoleBack);
        quadrantCConnectionHole.lineTo(connectionHoleLeft, -1 * connectionHoleBack);
        holes.push(quadrantCConnectionHole);
      }

      if (x !==0 && z !== 0) {
        const quadrantDConnectionHole = new THREE.Path();
        quadrantDConnectionHole.moveTo(-1 * connectionHoleLeft, -1 * connectionHoleFore);
        quadrantDConnectionHole.lineTo(-1 * connectionHoleRight, -1 * connectionHoleFore);
        quadrantDConnectionHole.lineTo(-1 * connectionHoleRight, -1 * connectionHoleBack);
        quadrantDConnectionHole.lineTo(-1 * connectionHoleLeft, -1 * connectionHoleBack);
        holes.push(quadrantDConnectionHole);
      }
    }
  }

  ceilingGridShape.holes = holes;

  return ceilingGridShape;
}


// ceiling grid grometry
const newCeilingGridGeometry = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  return new THREE.ExtrudeGeometry(
    newCeilingGridShape(roomHorizontalTileNumber, roomVerticalTileNumber),
    {
      'depth': 0.12,
      'bevelEnabled': false,
    }
  );
}

// ceiling grid material
const newCeilingGridMaterial = function () {
  const ceilingGridMaterial = new THREE.MeshStandardMaterial({ color: 0x517C9C });
  ceilingGridMaterial.side = THREE.DoubleSide;
  ceilingGridMaterial.roughness = 0.12;
  ceilingGridMaterial.metalness = 0.84;
  ceilingGridMaterial.flatShading = true;
  ceilingGridMaterial.envMapIntensity = 1.8;
  return ceilingGridMaterial;
}
const ceilingGridMaterial = newCeilingGridMaterial();

// ceiling grid mesh
const newCeilingGridMesh = function(roomHorizontalTileNumber, roomVerticalTileNumber) {
  const ceilingGridMesh = new THREE.Mesh(
    newCeilingGridGeometry(roomHorizontalTileNumber, roomVerticalTileNumber),
    ceilingGridMaterial
  );
  ceilingGridMesh.rotation.x = Math.PI / 2;
  return ceilingGridMesh;
}

//ceiling light
const newCeilingLightGeometry = function () {
  return new THREE.PlaneGeometry(4.8, 19.2);
}
const ceilingLightGeometry = newCeilingLightGeometry();

const newCeilingLightMaterial = function () {
  return new THREE.MeshBasicMaterial({ color: 0xffffff });
}
const ceilingLightMaterial = newCeilingLightMaterial();

const newCeilingLightMesh = function () {
  const mesh = new THREE.Mesh(ceilingLightGeometry, ceilingLightMaterial);
  mesh.position.y = -0.024;
  mesh.rotation.x = Math.PI / 2;
  return mesh;
}

// entire ceiling
const newCeilingMesh = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const groupMesh = new THREE.Group();
  groupMesh.position.y = roomHeight;
  groupMesh.add(
    newCeilingBaseMesh(roomHorizontalTileNumber, roomVerticalTileNumber),
    newCeilingGridMesh(roomHorizontalTileNumber, roomVerticalTileNumber)
  );
  
  const halfRoomWidth = (roomHorizontalTileNumber + 3) * halfFloorTileWidth;
  const halfRoomDepth = (roomVerticalTileNumber + 3) * halfFloorTileDepth;
  for (let z = 0; z + 9.6 < halfRoomDepth; z += 24.48) {
    for (let x = 0; x + 2.4 < halfRoomWidth; x += 24.48) {
      const quadrantALightMesh = newCeilingLightMesh();
      quadrantALightMesh.position.x = x;
      quadrantALightMesh.position.z = z;
      groupMesh.add(quadrantALightMesh);

      if (x !== 0) {
        const quadrantBLightMesh = newCeilingLightMesh();
        quadrantBLightMesh.position.x = -1 * x;
        quadrantBLightMesh.position.z = z;
        groupMesh.add(quadrantBLightMesh);
      }

      if ( z !== 0 ) {
        const quadrantCLightMesh = newCeilingLightMesh();
        quadrantCLightMesh.position.x = x;
        quadrantCLightMesh.position.z = -1 * z;
        groupMesh.add(quadrantCLightMesh);
      }

      if ( x !== 0 && z !== 0) {
        const quadrantDLightMesh = newCeilingLightMesh();
        quadrantDLightMesh.position.x = -1 * x;
        quadrantDLightMesh.position.z = -1 * z;
        groupMesh.add(quadrantDLightMesh);
      }
    }
  }

  return groupMesh;
}

export { newCeilingMesh }