import * as THREE from '../three.module.min.js'

class RenderingComponent {
  static cartGeometry = this.getCartGeometry();

  static slotMaterial = this.getSlotMaterial();
  static slotAvailableMaterial = this.getSlotAvailableMaterial();
  static slotOccupiedMaterial = this.getSlotOccupiedMaterial();
  static highlightMaterial = this.getHighlightMaterial();
  static logoMaterial = this.getLogoMaterial();
  static cartMaterial = this.getCartMaterial();

  static getRackFrameGeometry () {

      const rackGeometry = new THREE.BufferGeometry();
      rackGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array([
          -4.8, 10, 6,
          -4.8, -10, 6,
          4.8, -10, 6,
          4.8, 10, 6,

          -4.8, 9.36, 6,
          -4.8, -9.36, 6,
          4.8, -9.36, 6,
          4.8, 9.36, 6,

          -4.16, 9.36, 6,
          -4.16, -9.36, 6,
          4.16, -9.36, 6,
          4.16, 9.36, 6,

          -4.8, 10, -6,
          -4.8, -10, -6,

          4.8, -10, -6,
          4.8, 10, -6,

          -4.16, 9.36, -6,
          -4.16, -9.36, -6,
          4.16, -9.36, -6,
          4.16, 9.36, -6,
      ]), 3));
      rackGeometry.setIndex([
          0, 4, 7,
          7, 3, 0,
          4, 5, 9,
          9, 8, 4,
          5, 1, 2,
          2, 6, 5,
          11, 10, 6,
          6, 7, 11,

          12, 13, 1,
          1, 0, 12,

          3, 2, 14,
          14, 15, 3,

          8, 16, 19,
          19, 11, 8,

          8, 9, 17,
          17, 16, 8,

          17, 9, 10,
          10, 18, 17,

          19, 18, 10,
          10, 11, 19
      ]);

      return () => { return rackGeometry; }
  }

  static getCartGeometry () {
    const cartGeometry = new THREE.PlaneGeometry(6, 6);
    return () => { return cartGeometry; };
  }

  static getLogoMaterial () {
    const floorEnvTexture = new THREE.CubeTextureLoader().load([
        '../r/3d/texture/env/px.png',
        '../r/3d/texture/env/nx.png',
        '../r/3d/texture/env/py.png',
        '../r/3d/texture/env/ny.png',
        '../r/3d/texture/env/pz.png',
        '../r/3d/texture/env/nz.png'
    ]);
    const logoMaterial = new THREE.MeshPhysicalMaterial({ color : 0xE1F1FA });
    logoMaterial.roughness = 0.48;
    logoMaterial.map = new THREE.TextureLoader().load('../r/3d/texture/logo2.png');
    logoMaterial.envMap = floorEnvTexture;
    logoMaterial.envMapIntensity = 3.6;
    logoMaterial.transmission = 0.72;
    logoMaterial.thickness = 0.24;
    logoMaterial.clearcoat = 1;
    logoMaterial.clearcoatRoughness = 0.06;

    return () => { return logoMaterial; }
  }

  static getCartMaterial () {
    const floorEnvTexture = new THREE.CubeTextureLoader().load([
        '../r/3d/texture/env/px.png',
        '../r/3d/texture/env/nx.png',
        '../r/3d/texture/env/py.png',
        '../r/3d/texture/env/ny.png',
        '../r/3d/texture/env/pz.png',
        '../r/3d/texture/env/nz.png'
    ]);
    const cartMeterial = new THREE.MeshPhysicalMaterial({ color : 0xE1F1FA });
    cartMeterial.roughness = 0.48;
    cartMeterial.envMap = floorEnvTexture;
    cartMeterial.envMapIntensity = 3.6;
    cartMeterial.transmission = 0.72;
    cartMeterial.thickness = 0.24;
    cartMeterial.clearcoat = 1;
    cartMeterial.clearcoatRoughness = 0.06;

    return () => { return cartMeterial; }
  }

}

export { RenderingComponent };