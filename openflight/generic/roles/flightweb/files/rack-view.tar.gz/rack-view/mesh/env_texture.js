import { CubeTextureLoader } from "../three.module.min.js";

const envTexture = new CubeTextureLoader().load([
    '../r/3d/texture/env/px.png',
    '../r/3d/texture/env/nx.png',
    '../r/3d/texture/env/py.png',
    '../r/3d/texture/env/ny.png',
    '../r/3d/texture/env/pz.png',
    '../r/3d/texture/env/nz.png'
]);

export { envTexture }