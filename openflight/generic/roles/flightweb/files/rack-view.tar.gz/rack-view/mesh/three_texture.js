import * as THREE from '../three.module.min.js'

import {
  floorTileWidth,
  floorTileDepth
} from '../spec.js'

const textureLoader = new THREE.TextureLoader();


// room
//// ceiling
const newCeilingTexture = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
    const roomWidth = (roomHorizontalTileNumber + 3) * floorTileWidth;
    const roomDepth = (roomVerticalTileNumber + 3) * floorTileDepth;
    
    const ceilingTexture = textureLoader.load('../r/3d/texture/ceiling.png');
    ceilingTexture.wrapS = THREE.RepeatWrapping;
    ceilingTexture.wrapT = THREE.RepeatWrapping;
    ceilingTexture.offset = new THREE.Vector2(
        - (roomWidth / 2 - 2.4) % 24.48 / 24.48,
        - (roomDepth / 2 - 14.88) % 24.48 / 24.48,
    );
    ceilingTexture.repeat = new THREE.Vector2(roomWidth / 24.48, roomDepth / 24.48);
    ceilingTexture.magFilter = THREE.NearestFilter;

    return ceilingTexture;
}

const newCeilingRoughnessTexture = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
    const roomWidth = (roomHorizontalTileNumber + 3) * floorTileWidth;
    const roomDepth = (roomVerticalTileNumber + 3) * floorTileDepth;
    
    const texture = textureLoader.load('../r/3d/texture/ceiling_roughness.png');
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.offset = new THREE.Vector2(
        - (roomWidth / 2 - 2.4) % 24.48 / 24.48,
        - (roomDepth / 2 - 14.88) % 24.48 / 24.48,
    );
    texture.repeat = new THREE.Vector2(roomWidth / 24.48, roomDepth / 24.48);
    texture.magFilter = THREE.NearestFilter;

    return texture;
}

const newCeilingMetalnessTexture = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
    const roomWidth = (roomHorizontalTileNumber + 3) * floorTileWidth;
    const roomDepth = (roomVerticalTileNumber + 3) * floorTileDepth;
    
    const texture = textureLoader.load('../r/3d/texture/ceiling_metalness.png');
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.offset = new THREE.Vector2(
        - (roomWidth / 2 - 2.4) % 24.48 / 24.48,
        - (roomDepth / 2 - 14.88) % 24.48 / 24.48,
    );
    texture.repeat = new THREE.Vector2(roomWidth / 24.48, roomDepth / 24.48);
    texture.magFilter = THREE.NearestFilter;

    return texture;
}

//// floor
const newFloorTexture = function(roomHorizontalTileNumber, roomVerticalTileNumber) {
  const texture = textureLoader.load('../r/3d/texture/floor.png');
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.offset = new THREE.Vector2(0.5, 0.5);
  texture.repeat = new THREE.Vector2(roomHorizontalTileNumber + 3, roomVerticalTileNumber + 3);
  texture.magFilter = THREE.NearestFilter;

  return texture;
}

const newFloorNormalTexture = function(roomHorizontalTileNumber, roomVerticalTileNumber) {
  const texture = textureLoader.load('../r/3d/texture/floor_normal.png');
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.offset = new THREE.Vector2(0.5, 0.5);
  texture.repeat = new THREE.Vector2(roomHorizontalTileNumber + 3, roomVerticalTileNumber + 3);
  texture.magFilter = THREE.NearestFilter;
  
  return texture;
}

const newFloorRoughnessTexture = function(roomHorizontalTileNumber, roomVerticalTileNumber) {
  const texture = textureLoader.load('../r/3d/texture/floor_roughness.png');
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.offset = new THREE.Vector2(0.5, 0.5);
  texture.repeat = new THREE.Vector2(roomHorizontalTileNumber + 3, roomVerticalTileNumber + 3);
  texture.magFilter = THREE.NearestFilter;
  
  return texture;
}
// rack
//// rack enclosure
////// rack enclosure post light
const rackEnclosurePostLightTexture = textureLoader.load('../r/3d/texture/rack_enclosure_post_light.png');

////// rack enclosure wall
const rackEnclosureWallTexture = textureLoader.load('../r/3d/texture/rack_enclosure_wall.png');
rackEnclosureWallTexture.wrapT = THREE.RepeatWrapping;
rackEnclosureWallTexture.repeat = new THREE.Vector2(1, 7);

//// rack rail
const rackRailTextures = [];

const leftRackRailTexture = textureLoader.load('../r/3d/texture/rack_rail_left.png');
const leftRackRailRoughnessTexture = textureLoader.load('../r/3d/texture/rack_rail_left_roughness.png');
const leftRackRailNormalTexture = textureLoader.load('../r/3d/texture/rack_rail_left_normal.png');

const rightRackRailTexture = textureLoader.load('../r/3d/texture/rack_rail_right.png');
const rightRackRailNormalTexture = textureLoader.load('../r/3d/texture/rack_rail_right_normal.png');
const rightRackRailRoughnessTexture = textureLoader.load('../r/3d/texture/rack_rail_right_roughness.png');

rackRailTextures.push(
  leftRackRailTexture,
  leftRackRailRoughnessTexture,
  leftRackRailNormalTexture,
  rightRackRailTexture,
  rightRackRailNormalTexture,
  rightRackRailRoughnessTexture
);

for (const rackRailTexture of rackRailTextures) {
  rackRailTexture.wrapT = THREE.RepeatWrapping;
  rackRailTexture.repeat = new THREE.Vector2(1, 42);
  rackRailTexture.magFilter = THREE.NearestFilter;
}

// node
//// 1u node
const nodePanel1uStatusLightOnTexture = textureLoader.load('../r/3d/texture/node_1u_status_light_on.png');
const nodePanel1uStatusLightOffTexture = textureLoader.load('../r/3d/texture/node_1u_status_light_off.png');
const nodePanelDecorationLightBlueTexture = textureLoader.load('../r/3d/texture/node_panel_decoration_light_blue.png');
const nodePanelDecorationLightYellowTexture = textureLoader.load('../r/3d/texture/node_panel_decoration_light_yellow.png');

//// 1u login node
const loginNode1uStatusLightOnTexture = textureLoader.load('../r/3d/texture/login_node_1u_status_light_on.png');
const loginNode1uStatusLightOffTexture = textureLoader.load('../r/3d/texture/login_node_1u_status_light_off.png');

//// 4u storage node
const storageNode4uStatusLightOnTexture = textureLoader.load('../r/3d/texture/storage_node_4u_status_light_on.png');
const storageNode4uStatusLightOffTexture = textureLoader.load('../r/3d/texture/storage_node_4u_status_light_off.png');

export {
  newCeilingTexture,
  newCeilingRoughnessTexture,
  newCeilingMetalnessTexture,
  
  newFloorTexture,
  newFloorNormalTexture,
  newFloorRoughnessTexture,

  rackEnclosurePostLightTexture,
  rackEnclosureWallTexture,

  leftRackRailTexture,
  leftRackRailRoughnessTexture,
  leftRackRailNormalTexture,
  rightRackRailTexture,
  rightRackRailRoughnessTexture,
  rightRackRailNormalTexture,

  nodePanel1uStatusLightOnTexture,
  nodePanel1uStatusLightOffTexture,
  nodePanelDecorationLightBlueTexture,
  nodePanelDecorationLightYellowTexture,
  loginNode1uStatusLightOnTexture,
  loginNode1uStatusLightOffTexture,
  storageNode4uStatusLightOnTexture,
  storageNode4uStatusLightOffTexture
}