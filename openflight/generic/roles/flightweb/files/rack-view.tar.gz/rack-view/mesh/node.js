import * as THREE from '../three.module.min.js'
import { SVGLoader } from '../a/loaders/SVGLoader.js'

import {
  equipmentBodyWidth,
  equipmentBodyDepth,
  equipmentPanelWidth,
  equipmentPanelDepth,
  halfEquipmentBodyDepth,
  equipment1uPanelHeight,
  equipment1uBodyHeight,
  halfEquipmentPanelWidth,
  halfEquipment1uPanelHeight,
  equipmentContentHorizontalPadding,
  halfEquipment4uPanelHeight,
  equipmentContentVerticalPadding,
  storageNodeStatusLightWidth,
  equipment4uPanelHeight,
  equipment4uContentHeight,
  storageNodeHardDriveSlotHorizontalGap,
  hardDriveSlotWidth,
  hardDriveSlotHeight,
  storageNode4uHardDriveSlotVerticalGap,
  storageNodeHardDriveSlotRadius,
  hardDriveBayDepth,
  equipment4uBodyHeight
} from '../spec.js'

import {
  nodePanelDecorationLightBlueTexture,
  nodePanelDecorationLightYellowTexture,
  nodePanel1uStatusLightOffTexture,
  nodePanel1uStatusLightOnTexture,
  storageNode4uStatusLightOffTexture,
  storageNode4uStatusLightOnTexture,
  loginNode1uStatusLightOnTexture,
  loginNode1uStatusLightOffTexture,
} from './three_texture.js'

import {
  newHardDriveBayMesh
} from './hard_drive.js';

// constants
const panelLightDepth = 0.036;
const panelStatusLightRadius = 0.024;
const nodePanelStatusLightHoleWidth = equipmentPanelWidth - 0.24;
const nodePanelStatusLightHoleHeight = equipment1uPanelHeight - 0.168;
const halfNodePanelStatusLightHoleWidth = nodePanelStatusLightHoleWidth / 2;
const halfNodePanelStatusLightHoleHeight = nodePanelStatusLightHoleHeight / 2;
const decorationLightRadius = 0.382 * halfNodePanelStatusLightHoleHeight;
const decorationLightSpacing = 4.4 * decorationLightRadius;

// geometry
//// 1u node
////// panel
const nodePanel1uFrameShape = new THREE.Shape();
nodePanel1uFrameShape.moveTo(-halfEquipmentPanelWidth, halfEquipment1uPanelHeight);
nodePanel1uFrameShape.lineTo(halfEquipmentPanelWidth, halfEquipment1uPanelHeight);
nodePanel1uFrameShape.lineTo(halfEquipmentPanelWidth, -halfEquipment1uPanelHeight);
nodePanel1uFrameShape.lineTo(-halfEquipmentPanelWidth, -halfEquipment1uPanelHeight);

  const nodePanel1uStatusLightHole = new THREE.Path();
  nodePanel1uStatusLightHole.moveTo(-halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight - panelStatusLightRadius);
  nodePanel1uStatusLightHole.arc(panelStatusLightRadius, 0, panelStatusLightRadius, Math.PI, Math.PI / 2, true);
  nodePanel1uStatusLightHole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight);
  nodePanel1uStatusLightHole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 2 * panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight + 2 * panelStatusLightRadius);
  nodePanel1uStatusLightHole.lineTo(halfNodePanelStatusLightHoleWidth - panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight + 2 * panelStatusLightRadius);
  nodePanel1uStatusLightHole.arc(0, -panelStatusLightRadius, panelStatusLightRadius, Math.PI / 2, Math.PI / -2, true);
  nodePanel1uStatusLightHole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 4 * panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight);
  nodePanel1uStatusLightHole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 4 * panelStatusLightRadius - 0.382 * nodePanelStatusLightHoleHeight, halfNodePanelStatusLightHoleHeight - 0.618 * nodePanelStatusLightHoleHeight);
  nodePanel1uStatusLightHole.lineTo(-halfNodePanelStatusLightHoleWidth + panelStatusLightRadius, (1 - 2 * 0.618) * halfNodePanelStatusLightHoleHeight);
  nodePanel1uStatusLightHole.arc(0, panelStatusLightRadius, panelStatusLightRadius, 3 * Math.PI / 2, Math.PI, true);

  const nodePanel1uDecorationLight5Hole = new THREE.Path();
  nodePanel1uDecorationLight5Hole.moveTo(halfNodePanelStatusLightHoleWidth - decorationLightRadius, halfNodePanelStatusLightHoleHeight);
  nodePanel1uDecorationLight5Hole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);

  const nodePanel1uDecorationLight4Hole = new THREE.Path();
  nodePanel1uDecorationLight4Hole.moveTo(halfNodePanelStatusLightHoleWidth - decorationLightRadius - decorationLightSpacing, halfNodePanelStatusLightHoleHeight);
  nodePanel1uDecorationLight4Hole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);
  
  const nodePanel1uDecorationLight3Hole = new THREE.Path();
  nodePanel1uDecorationLight3Hole.moveTo(halfNodePanelStatusLightHoleWidth - decorationLightRadius - 2 * decorationLightSpacing, halfNodePanelStatusLightHoleHeight);
  nodePanel1uDecorationLight3Hole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);
  
  const nodePanel1uDecorationLight2Hole = new THREE.Path();
  nodePanel1uDecorationLight2Hole.moveTo(halfNodePanelStatusLightHoleWidth - decorationLightRadius - 3 * decorationLightSpacing, halfNodePanelStatusLightHoleHeight);
  nodePanel1uDecorationLight2Hole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);
  
  const nodePanel1uDecorationLight1Hole = new THREE.Path();
  nodePanel1uDecorationLight1Hole.moveTo(halfNodePanelStatusLightHoleWidth - decorationLightRadius - 4 * decorationLightSpacing, halfNodePanelStatusLightHoleHeight);
  nodePanel1uDecorationLight1Hole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);

nodePanel1uFrameShape.holes = [nodePanel1uStatusLightHole, nodePanel1uDecorationLight1Hole, nodePanel1uDecorationLight2Hole, nodePanel1uDecorationLight3Hole, nodePanel1uDecorationLight4Hole, nodePanel1uDecorationLight5Hole];

const nodePanel1uFrameGeometry = new THREE.ExtrudeGeometry(
  nodePanel1uFrameShape,
  {
    'depth': equipmentPanelDepth,
    'bevelEnabled': false,
  }
);

////// node status light
const nodePanel1uStatusLightShape = new THREE.Shape();
nodePanel1uStatusLightShape.moveTo(-halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight);
nodePanel1uStatusLightShape.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight);
nodePanel1uStatusLightShape.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 2 * panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight + 2 * panelStatusLightRadius);
nodePanel1uStatusLightShape.lineTo(halfNodePanelStatusLightHoleWidth, -halfNodePanelStatusLightHoleHeight + 2 * panelStatusLightRadius);
nodePanel1uStatusLightShape.lineTo(halfNodePanelStatusLightHoleWidth, -halfNodePanelStatusLightHoleHeight);
nodePanel1uStatusLightShape.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 4 * panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight);
nodePanel1uStatusLightShape.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 4 * panelStatusLightRadius - 0.382 * nodePanelStatusLightHoleHeight, halfNodePanelStatusLightHoleHeight - 0.618 * nodePanelStatusLightHoleHeight);
nodePanel1uStatusLightShape.lineTo(-halfNodePanelStatusLightHoleWidth, (1 - 2 * 0.618) * halfNodePanelStatusLightHoleHeight);

/**
 * compute the uv coordinates for the given shape geometry.
 * @param {THREE.ShapeGeometry} shapeGeometry 
 */
const computeShapeGeometryUV = function (shapeGeometry) {

  shapeGeometry.computeBoundingBox();
  const boundingBox = shapeGeometry.boundingBox;
  const boundingBoxSize = new THREE.Vector3();
  boundingBox.getSize(boundingBoxSize);

  const shapeLeft = boundingBox.min.x;
  const shapeBottom = boundingBox.min.y;
  const shapeWidth = boundingBoxSize.x;
  const shapeHeight = boundingBoxSize.y;

  const shapePositionAttribute = shapeGeometry.getAttribute('position');
  const shapePositionArray = shapePositionAttribute.array;
  const shapeUVArray = new Float32Array(shapePositionAttribute.count * 2);
  for (let i = 0; i < shapePositionAttribute.count; i++) {
    const vertexX = shapePositionArray[i * shapePositionAttribute.itemSize];
    const vertexY = shapePositionArray[i * shapePositionAttribute.itemSize + 1];
    // const vertexZ = shapePositionArray[i * shapePositionAttribute.itemSize + 2];
    
    shapeUVArray[i * 2] = (vertexX - shapeLeft) / shapeWidth;
    shapeUVArray[i * 2 + 1] = (vertexY - shapeBottom) / shapeHeight;
  }
  shapeGeometry.setAttribute('uv', new THREE.BufferAttribute(shapeUVArray, 2));
}

const nodePanel1uStatusLightGeometry = new THREE.ShapeGeometry(nodePanel1uStatusLightShape);
computeShapeGeometryUV(nodePanel1uStatusLightGeometry);

////// node decoration light
const nodePanelDecorationLightGeometry = new THREE.PlaneGeometry(2 * decorationLightRadius, 2 * decorationLightRadius);

////// node body
const nodeBody1uGeometry = new THREE.BoxGeometry(equipmentBodyWidth, equipment1uBodyHeight, equipmentBodyDepth);

//// 1u login node
////// panel
const loginNodePanel1uFrameShape = new THREE.Shape();
loginNodePanel1uFrameShape.moveTo(-halfEquipmentPanelWidth, halfEquipment1uPanelHeight);
loginNodePanel1uFrameShape.lineTo(halfEquipmentPanelWidth, halfEquipment1uPanelHeight);
loginNodePanel1uFrameShape.lineTo(halfEquipmentPanelWidth, -halfEquipment1uPanelHeight);
loginNodePanel1uFrameShape.lineTo(-halfEquipmentPanelWidth, -halfEquipment1uPanelHeight);

  const loginNodePanel1u1uStatusLight1Hole = new THREE.Path();
  loginNodePanel1u1uStatusLight1Hole.moveTo(-halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight - panelStatusLightRadius);
  loginNodePanel1u1uStatusLight1Hole.arc(panelStatusLightRadius, 0, panelStatusLightRadius, Math.PI, Math.PI / 2, true);
  loginNodePanel1u1uStatusLight1Hole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight1Hole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - panelStatusLightRadius / Math.sin(Math.PI / 4) - panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight + panelStatusLightRadius / Math.sin(Math.PI / 4) + panelStatusLightRadius);
  loginNodePanel1u1uStatusLight1Hole.arc(-panelStatusLightRadius, -panelStatusLightRadius, panelStatusLightRadius / Math.sin(Math.PI / 4), Math.PI / 4, 5 * Math.PI / 4, true);
  loginNodePanel1u1uStatusLight1Hole.lineTo((-1 + 2 * 0.382) * halfNodePanelStatusLightHoleWidth + nodePanelStatusLightHoleHeight - 4 * panelStatusLightRadius - 0.382 * nodePanelStatusLightHoleHeight, halfNodePanelStatusLightHoleHeight - 0.618 * nodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight1Hole.lineTo(-halfNodePanelStatusLightHoleWidth + panelStatusLightRadius, (1 - 2 * 0.618) * halfNodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight1Hole.arc(0, panelStatusLightRadius, panelStatusLightRadius, 3 * Math.PI / 2, Math.PI, true);
  
  const loginNodePanel1u1uStatusLight2Hole = new THREE.Path();
  loginNodePanel1u1uStatusLight2Hole.moveTo(halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight - panelStatusLightRadius);
  loginNodePanel1u1uStatusLight2Hole.arc(-panelStatusLightRadius, 0, panelStatusLightRadius, 0, Math.PI / 2);
  loginNodePanel1u1uStatusLight2Hole.lineTo((1 - 2 * 0.382) * halfNodePanelStatusLightHoleWidth, halfNodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight2Hole.lineTo((1 - 2 * 0.382) * halfNodePanelStatusLightHoleWidth - nodePanelStatusLightHoleHeight + panelStatusLightRadius / Math.sin(Math.PI / 4) + panelStatusLightRadius, -halfNodePanelStatusLightHoleHeight + panelStatusLightRadius / Math.sin(Math.PI / 4) + panelStatusLightRadius);
  loginNodePanel1u1uStatusLight2Hole.arc(panelStatusLightRadius, -panelStatusLightRadius, panelStatusLightRadius / Math.sin(Math.PI / 4), 3 * Math.PI / 4, 7 * Math.PI / 4);
  loginNodePanel1u1uStatusLight2Hole.lineTo((1 - 2 * 0.382) * halfNodePanelStatusLightHoleWidth - nodePanelStatusLightHoleHeight + 4 * panelStatusLightRadius + 0.382 * nodePanelStatusLightHoleHeight, halfNodePanelStatusLightHoleHeight - 0.618 * nodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight2Hole.lineTo(halfNodePanelStatusLightHoleWidth - panelStatusLightRadius, (1 - 2 * 0.618) * halfNodePanelStatusLightHoleHeight);
  loginNodePanel1u1uStatusLight2Hole.arc(0, panelStatusLightRadius, panelStatusLightRadius, 3 * Math.PI / 2, 0);

  const svgLoader = new SVGLoader();
  const loginNodePanelLogoData = await svgLoader.loadAsync('../r/3d/shape/logo.svg');
  const loginNodePanelLogoHole = loginNodePanelLogoData.paths[0].subPaths[0];

loginNodePanel1uFrameShape.holes=[loginNodePanel1u1uStatusLight1Hole, loginNodePanel1u1uStatusLight2Hole, loginNodePanelLogoHole];
const loginNodePanel1uFrameGeometry = new THREE.ExtrudeGeometry(
  loginNodePanel1uFrameShape,
  {
    'depth': equipmentPanelDepth,
    'bevelEnabled': false,
  }
);

////// status light
const loginNode1uStatusLightGeometry = new THREE.PlaneGeometry(equipmentPanelWidth - 2 * equipmentContentHorizontalPadding, equipment1uPanelHeight - 2 * equipmentContentVerticalPadding);

//// 4u storage node
////// panel
const storageNodePanel4uFrameShape = new THREE.Shape();
storageNodePanel4uFrameShape.moveTo(-halfEquipmentPanelWidth, halfEquipment4uPanelHeight);
storageNodePanel4uFrameShape.lineTo(halfEquipmentPanelWidth, halfEquipment4uPanelHeight);
storageNodePanel4uFrameShape.lineTo(halfEquipmentPanelWidth, -halfEquipment4uPanelHeight);
storageNodePanel4uFrameShape.lineTo(-halfEquipmentPanelWidth, -halfEquipment4uPanelHeight);

  const storageNodePanel4uStatusLightHole = new THREE.Path();
  storageNodePanel4uStatusLightHole.moveTo(-halfEquipmentPanelWidth + equipmentContentHorizontalPadding, halfEquipment4uPanelHeight - equipmentContentVerticalPadding - panelStatusLightRadius);
  storageNodePanel4uStatusLightHole.arc(panelStatusLightRadius, 0, panelStatusLightRadius, Math.PI, Math.PI / 2, true);
  storageNodePanel4uStatusLightHole.lineTo(-halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth - panelStatusLightRadius, halfEquipment4uPanelHeight - equipmentContentVerticalPadding);
  storageNodePanel4uStatusLightHole.arc(0, -panelStatusLightRadius, panelStatusLightRadius, Math.PI / 2, 0, true);
  storageNodePanel4uStatusLightHole.lineTo(-halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth, -halfEquipment4uPanelHeight + equipmentContentVerticalPadding + panelStatusLightRadius);
  storageNodePanel4uStatusLightHole.arc(-panelStatusLightRadius, 0, panelStatusLightRadius, 0, Math.PI / -2, true);
  storageNodePanel4uStatusLightHole.lineTo(-halfEquipmentPanelWidth + equipmentContentHorizontalPadding + panelStatusLightRadius, -halfEquipment4uPanelHeight + equipmentContentVerticalPadding);
  storageNodePanel4uStatusLightHole.arc(0, panelStatusLightRadius, panelStatusLightRadius, 3 * Math.PI / 2, Math.PI, true);

  let storageNodePanel4uHardDriveSlotHoles = [];
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 5; j++) {
      const hole = new THREE.Path();
      hole.moveTo(
        -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth + storageNodeHardDriveSlotHorizontalGap + (hardDriveSlotWidth + storageNodeHardDriveSlotHorizontalGap) * i,
        halfEquipment4uPanelHeight - equipmentContentVerticalPadding - storageNodeHardDriveSlotRadius - (hardDriveSlotHeight + storageNode4uHardDriveSlotVerticalGap) * j
      );
      hole.arc(storageNodeHardDriveSlotRadius, 0, storageNodeHardDriveSlotRadius, Math.PI, Math.PI / 2, true);
      hole.lineTo(
        -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth + storageNodeHardDriveSlotHorizontalGap + (hardDriveSlotWidth + storageNodeHardDriveSlotHorizontalGap) * i + hardDriveSlotWidth - storageNodeHardDriveSlotRadius,
        halfEquipment4uPanelHeight - equipmentContentVerticalPadding - (hardDriveSlotHeight + storageNode4uHardDriveSlotVerticalGap) * j
      );
      hole.arc(0, -storageNodeHardDriveSlotRadius, storageNodeHardDriveSlotRadius, Math.PI / 2, 0, true);
      hole.lineTo(
        -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth + storageNodeHardDriveSlotHorizontalGap + (hardDriveSlotWidth + storageNodeHardDriveSlotHorizontalGap) * i + hardDriveSlotWidth,
        halfEquipment4uPanelHeight - equipmentContentVerticalPadding - (hardDriveSlotHeight + storageNode4uHardDriveSlotVerticalGap) * j - hardDriveSlotHeight + storageNodeHardDriveSlotRadius
      );
      hole.arc(-storageNodeHardDriveSlotRadius, 0, storageNodeHardDriveSlotRadius, 0, Math.PI / -2, true);
      hole.lineTo(
        -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth + storageNodeHardDriveSlotHorizontalGap + (hardDriveSlotWidth + storageNodeHardDriveSlotHorizontalGap) * i + storageNodeHardDriveSlotRadius,
        halfEquipment4uPanelHeight - equipmentContentVerticalPadding - (hardDriveSlotHeight + storageNode4uHardDriveSlotVerticalGap) * j - hardDriveSlotHeight
      );
      hole.arc(0, storageNodeHardDriveSlotRadius, storageNodeHardDriveSlotRadius, 3 * Math.PI / 2, Math.PI, true);
      storageNodePanel4uHardDriveSlotHoles.push(hole);
    }
  }

storageNodePanel4uFrameShape.holes = [storageNodePanel4uStatusLightHole, ...storageNodePanel4uHardDriveSlotHoles];

const storageNodePanel4uFrameGeometry = new THREE.ExtrudeGeometry(
  storageNodePanel4uFrameShape,
  {
    'depth': equipmentPanelDepth,
    'bevelEnabled': false,
  }
);

////// node status light
const storageNode4uStatusLightGeometry = new THREE.PlaneGeometry(storageNodeStatusLightWidth, equipment4uContentHeight);

////// node body
const nodeBody4uGeometry = new THREE.BoxGeometry(equipmentBodyWidth, equipment4uBodyHeight, equipmentBodyDepth);

//// panel collision box
const nodePanel1uCollisionGeometry = new THREE.PlaneGeometry(equipmentPanelWidth, equipment1uPanelHeight);
const nodePanel4uCollisionGeometry = new THREE.PlaneGeometry(equipmentPanelWidth, equipment4uPanelHeight);

// material
//// common material
const nodeMaterial = new THREE.MeshStandardMaterial({
  'side': THREE.DoubleSide,
  'color': 0x517C9C,
  'roughness': 0.24,
  'metalness': 0.96
});

const nodeHoveredMaterial = new THREE.MeshPhysicalMaterial({
    'color': 'cyan',
    'emissive': 'cyan',
    'emissiveIntensity': 0.24,
    'roughness': 0.36,
    'transmission': 1
});

//// 1u node
////// node status light
const nodePanel1uStatusLightOnMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xFFFFFF,
  'map': nodePanel1uStatusLightOnTexture
})

const nodePanel1uStatusLightOffMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xFFFFFF,
  'map': nodePanel1uStatusLightOffTexture
})

////// node decoration light
const nodePanelDecorationLightBlueMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0x2794D8,
  'map': nodePanelDecorationLightBlueTexture
})

const nodePanelDecorationLightYellowMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xEBD742,
  'map': nodePanelDecorationLightYellowTexture
})

const nodePanelDecorationLightOffMaterial = new THREE.MeshStandardMaterial({
  'side': THREE.DoubleSide,
  'color': 0x404040,
  'roughness': 0.36
})

const nodePanelCollisionMaterial = new THREE.MeshBasicMaterial({
  'visible': false
});

//// 1u login node
////// status light
const loginNode1uStatusLightOnMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xFFFFFF,
  'map': loginNode1uStatusLightOnTexture
});

const loginNode1uStatusLightOffMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xFFFFFF,
  'map': loginNode1uStatusLightOffTexture
});

//// 4u storage node
////// node status light
const storageNode4uStatusLightOnMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0xFFFFFF,
  'map': storageNode4uStatusLightOnTexture
})

const storageNode4uStatusLightOffMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  // 'color': 0xFFFFFF,
  'map': storageNode4uStatusLightOffTexture
})

// mesh
//// 1u node
////// node panel
const newNodePanel1uFrameMesh = function () {
  return new THREE.Mesh(nodePanel1uFrameGeometry, nodeMaterial);
}

const newNodePanel1uStatusLightMesh = function () {
  return new THREE.Mesh(nodePanel1uStatusLightGeometry, nodePanel1uStatusLightOnMaterial);
}

const newNodePanel1uDecorationLightBlueMesh = function () {
  return new THREE.Mesh(nodePanelDecorationLightGeometry, nodePanelDecorationLightBlueMaterial);
}

const newNodePanel1uDecorationLightYellowMesh = function () {
  return new THREE.Mesh(nodePanelDecorationLightGeometry, nodePanelDecorationLightYellowMaterial);
}

const newNodePanel1uCollisionMesh = function () {
  return new THREE.Mesh(nodePanel1uCollisionGeometry, nodePanelCollisionMaterial);
}

const newNodePanel4uCollisionMesh = function () {
  return new THREE.Mesh(nodePanel4uCollisionGeometry, nodePanelCollisionMaterial);
}

const newNodePanel1uMesh = function () {
  const groupMesh = new THREE.Group();

    const frameMesh = newNodePanel1uFrameMesh();

    const statusLightMesh = newNodePanel1uStatusLightMesh();
    statusLightMesh.position.z = equipmentPanelDepth - panelLightDepth;

    const decorationLight1Mesh = newNodePanel1uDecorationLightBlueMesh();
    decorationLight1Mesh.position.x = halfNodePanelStatusLightHoleWidth - decorationLightRadius - 4 * decorationLightSpacing;
    decorationLight1Mesh.position.y = halfNodePanelStatusLightHoleHeight - decorationLightRadius;
    decorationLight1Mesh.position.z = equipmentPanelDepth - panelLightDepth;

    const decorationLight2Mesh = newNodePanel1uDecorationLightYellowMesh();
    decorationLight2Mesh.position.x = halfNodePanelStatusLightHoleWidth - decorationLightRadius - 3 * decorationLightSpacing;
    decorationLight2Mesh.position.y = halfNodePanelStatusLightHoleHeight - decorationLightRadius;
    decorationLight2Mesh.position.z = equipmentPanelDepth - panelLightDepth;

    const decorationLight3Mesh = newNodePanel1uDecorationLightYellowMesh();
    decorationLight3Mesh.position.x = halfNodePanelStatusLightHoleWidth - decorationLightRadius - 2 * decorationLightSpacing;
    decorationLight3Mesh.position.y = halfNodePanelStatusLightHoleHeight - decorationLightRadius;
    decorationLight3Mesh.position.z = equipmentPanelDepth - panelLightDepth;

    const decorationLight4Mesh = newNodePanel1uDecorationLightBlueMesh();
    decorationLight4Mesh.position.x = halfNodePanelStatusLightHoleWidth - decorationLightRadius - 1 * decorationLightSpacing;
    decorationLight4Mesh.position.y = halfNodePanelStatusLightHoleHeight - decorationLightRadius;
    decorationLight4Mesh.position.z = equipmentPanelDepth - panelLightDepth;

    const decorationLight5Mesh = newNodePanel1uDecorationLightYellowMesh();
    decorationLight5Mesh.position.x = halfNodePanelStatusLightHoleWidth - decorationLightRadius;
    decorationLight5Mesh.position.y = halfNodePanelStatusLightHoleHeight - decorationLightRadius;
    decorationLight5Mesh.position.z = equipmentPanelDepth - panelLightDepth;

    const collisionMesh = newNodePanel1uCollisionMesh();
    collisionMesh.position.z = equipmentPanelDepth;
  
  groupMesh.add(
    frameMesh,
    statusLightMesh,
    decorationLight1Mesh,
    decorationLight2Mesh,
    decorationLight3Mesh,
    decorationLight4Mesh,
    decorationLight5Mesh,
    collisionMesh
  );
  groupMesh.userData.interactiveChildren = {
    "panelCollisionMesh": collisionMesh,
    "panelFrameMesh": frameMesh,
    "statusLightMesh": statusLightMesh,
    "decorationLight1Mesh": decorationLight1Mesh,
    "decorationLight2Mesh": decorationLight2Mesh,
    "decorationLight3Mesh": decorationLight3Mesh,
    "decorationLight4Mesh": decorationLight4Mesh,
    "decorationLight5Mesh": decorationLight5Mesh
  }

  return groupMesh;
}

////// node body
const newNodeBody1uMesh = function () {
  return new THREE.Mesh(nodeBody1uGeometry, nodeMaterial);
}

////// entire node
const newNode1uMesh = function () {
  const groupMesh = new THREE.Group();
    
    const panelMesh = newNodePanel1uMesh();
    panelMesh.position.z = halfEquipmentBodyDepth;

    const bodyMesh = newNodeBody1uMesh();
    
  groupMesh.add(panelMesh, bodyMesh);
  groupMesh.userData.interactiveChildren = Object.assign(
    {
      'bodyMesh': bodyMesh
    },
    panelMesh.userData.interactiveChildren
  );

  return groupMesh;
}

//// 1u login node
////// panel
const newLoginNodePanel1uFrameMesh = function () {
  return new THREE.Mesh(loginNodePanel1uFrameGeometry, nodeMaterial);
}

const newLoginNode1uStatusLightMesh = function () {
  return new THREE.Mesh(loginNode1uStatusLightGeometry, loginNode1uStatusLightOnMaterial);
}

const newLoginNodePanel1uMesh = function () {
  const groupMesh = new THREE.Group();

    const frameMesh = newLoginNodePanel1uFrameMesh();

    const statusLightMesh = newLoginNode1uStatusLightMesh();
    statusLightMesh.position.z = equipmentPanelDepth - panelLightDepth;
  
    const collisionMesh = newNodePanel1uCollisionMesh();
    collisionMesh.position.z = equipmentPanelDepth;

  groupMesh.add(
    frameMesh,
    statusLightMesh,
    collisionMesh
  );
  groupMesh.userData.interactiveChildren = {
    "panelCollisionMesh": collisionMesh,
    "panelFrameMesh": frameMesh,
    "statusLightMesh": statusLightMesh
  }

  return groupMesh;
}

////// entire node
const newLoginNode1uMesh = function () {
  const groupMesh = new THREE.Group();
    
    const panelMesh = newLoginNodePanel1uMesh();
    panelMesh.position.z = halfEquipmentBodyDepth;

    const bodyMesh = newNodeBody1uMesh();
    
  groupMesh.add(
    panelMesh,
    bodyMesh
  );
  groupMesh.userData.interactiveChildren = Object.assign(
    {
      'bodyMesh': bodyMesh
    },
    panelMesh.userData.interactiveChildren
  );

  return groupMesh;
}

//// 4u storage node
////// panel
const newStorageNodePanel4uFrameMesh = function () {
  return new THREE.Mesh(storageNodePanel4uFrameGeometry, nodeMaterial);
}


const newStorageNode4uStatusLightMesh = function () {
  return new THREE.Mesh(storageNode4uStatusLightGeometry, storageNode4uStatusLightOnMaterial);
}

const newStorageNodePanel4uMesh = function () {
  const groupMesh = new THREE.Group();

    const frameMesh = newStorageNodePanel4uFrameMesh();

    const statusLightMesh = newStorageNode4uStatusLightMesh();
    statusLightMesh.position.x = -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth / 2;
    statusLightMesh.position.z = equipmentPanelDepth - panelLightDepth;
  
    const collisionMesh = newNodePanel4uCollisionMesh();
    collisionMesh.position.z = equipmentPanelDepth;

  groupMesh.add(
    frameMesh,
    statusLightMesh,
    collisionMesh
  );
  groupMesh.userData.interactiveChildren = {
    "panelCollisionMesh": collisionMesh,
    "panelFrameMesh": frameMesh,
    "statusLightMesh": statusLightMesh
  }

  return groupMesh;
}

////// body
const newNodeBody4uMesh = function () {
  return new THREE.Mesh(nodeBody4uGeometry, nodeMaterial);
}

////// entire node
const newStorageNode4uMesh = function () {
  const groupMesh = new THREE.Group();
    
    const panelMesh = newStorageNodePanel4uMesh();
    panelMesh.position.z = halfEquipmentBodyDepth;

    const bodyMesh = newNodeBody4uMesh();

    const hardDriveBayMeshes = [];
    const hardDriveBayFrameMeshes = [];
    const hardDriveBayVentsLiningMeshes = [];
    const hardDriveBayDecorationLightMeshes = [];
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 5; j++) {
        let hardDriveBayMesh;
        if ([0, 2, 6, 7, 8, 11, 12, 14, 15, 18].includes(5 * i + j)){
          hardDriveBayMesh = newHardDriveBayMesh('yellow');
        } else {
          hardDriveBayMesh = newHardDriveBayMesh('blue');
        }
        hardDriveBayMesh.position.x = -halfEquipmentPanelWidth + equipmentContentHorizontalPadding + storageNodeStatusLightWidth + storageNodeHardDriveSlotHorizontalGap + hardDriveSlotWidth / 2 + (hardDriveSlotWidth + storageNodeHardDriveSlotHorizontalGap) * i;
        hardDriveBayMesh.position.y = halfEquipment4uPanelHeight - equipmentContentVerticalPadding - hardDriveSlotHeight / 2 - (hardDriveSlotHeight + storageNode4uHardDriveSlotVerticalGap) * j;
        hardDriveBayMesh.position.z = halfEquipmentBodyDepth + equipmentPanelDepth - hardDriveBayDepth;
        hardDriveBayMeshes.push(hardDriveBayMesh);

        const hardDriveBayInteractiveChildren = hardDriveBayMesh.userData.interactiveChildren;
        hardDriveBayFrameMeshes.push(hardDriveBayInteractiveChildren.hardDriveBayFrameMesh);
        hardDriveBayVentsLiningMeshes.push(hardDriveBayInteractiveChildren.hardDriveBayLiningMesh);
        hardDriveBayDecorationLightMeshes.push(hardDriveBayInteractiveChildren.decorationLightMesh);
      }
    }
    
  groupMesh.add(
    panelMesh,
    bodyMesh,
    ...hardDriveBayMeshes
  );
  groupMesh.userData.interactiveChildren = Object.assign(
    {
      'bodyMesh': bodyMesh
    },
    panelMesh.userData.interactiveChildren
  );
  for (const index in hardDriveBayFrameMeshes) {
    groupMesh.userData.interactiveChildren[`hardDriveBayFrameMesh${index}`] = hardDriveBayFrameMeshes[index];
    groupMesh.userData.interactiveChildren[`hardDriveBayVentsLiningMesh${index}`] = hardDriveBayVentsLiningMeshes[index];
    groupMesh.userData.interactiveChildren[`decorationLightMesh${index}`] = hardDriveBayDecorationLightMeshes[index];
  }

  return groupMesh;
}

export {
  nodeMaterial,
  nodeHoveredMaterial,
  nodePanel1uStatusLightOnMaterial,
  nodePanel1uStatusLightOffMaterial,
  nodePanelDecorationLightBlueMaterial,
  nodePanelDecorationLightYellowMaterial,
  nodePanelDecorationLightOffMaterial,
  loginNode1uStatusLightOnMaterial,
  loginNode1uStatusLightOffMaterial,
  storageNode4uStatusLightOnMaterial,
  storageNode4uStatusLightOffMaterial,

  newNode1uMesh,
  newLoginNode1uMesh,
  newStorageNode4uMesh
}