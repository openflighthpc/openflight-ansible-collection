import * as THREE from '../three.module.min.js'
import {
  rackLiningWidth,
  halfRackLiningWidth,
  rackLiningHeight,
  rackLiningRadius,
  rackLiningDepth
} from '../spec.js'

// geometry
//// single rack lining
const singleRackLiningShape = new THREE.Shape();
singleRackLiningShape.moveTo(- halfRackLiningWidth, 0);
singleRackLiningShape.arc(rackLiningRadius, 0, rackLiningRadius, Math.PI, Math.PI / 2, true);
singleRackLiningShape.lineTo(halfRackLiningWidth - rackLiningRadius, rackLiningRadius);
singleRackLiningShape.arc(0, -rackLiningRadius, rackLiningRadius, Math.PI / 2, 0, true);

const singleRackLiningGeometry = new THREE.ExtrudeGeometry(
  singleRackLiningShape, 
  {
    'depth': rackLiningDepth,
    'bevelEnabled': false,
  }
);

//// left rack lining
const leftRackLiningShape = new THREE.Shape();
leftRackLiningShape.moveTo(- halfRackLiningWidth, 0);
leftRackLiningShape.arc(rackLiningRadius, 0, rackLiningRadius, Math.PI, Math.PI / 2, true);
leftRackLiningShape.lineTo(halfRackLiningWidth, rackLiningRadius);
leftRackLiningShape.lineTo(halfRackLiningWidth, 0);

const leftRackLiningGeometry = new THREE.ExtrudeGeometry(
  leftRackLiningShape, 
  {
    'depth': rackLiningDepth,
    'bevelEnabled': false,
  }
);

//// middle rack lining
const middleRackLiningGeometry = new THREE.BoxGeometry(rackLiningWidth, rackLiningHeight, rackLiningDepth);

//// right rack lining
const rightRackLiningShape = new THREE.Shape();
rightRackLiningShape.moveTo(-halfRackLiningWidth, 0);
rightRackLiningShape.lineTo(-halfRackLiningWidth, rackLiningRadius);
rightRackLiningShape.lineTo(halfRackLiningWidth - rackLiningRadius, rackLiningRadius);
rightRackLiningShape.arc(0, -rackLiningRadius, rackLiningRadius, Math.PI / 2, 0, true);

const rightRackLiningGeometry = new THREE.ExtrudeGeometry(
  rightRackLiningShape, 
  {
    'depth': rackLiningDepth,
    'bevelEnabled': false,
  }
);



// material
const rackLiningMaterial = new THREE.MeshStandardMaterial({
  'color': 0x517C9C
});
rackLiningMaterial.roughness = 0.36;
rackLiningMaterial.metalness = 0.96;



// mesh
//// single rack lining
const newSingleRackLiningMesh = function () {
  return new THREE.Mesh(singleRackLiningGeometry, rackLiningMaterial);
}

//// left rack lining
const newLeftRackLiningMesh = function () {
  return new THREE.Mesh(leftRackLiningGeometry, rackLiningMaterial);
}

//// middle rack lining
const newMiddleRackLiningMesh = function () {
  return new THREE.Mesh(middleRackLiningGeometry, rackLiningMaterial);
}

//// right rack lining
const newRightRackLiningMesh = function () {
  return new THREE.Mesh(rightRackLiningGeometry, rackLiningMaterial);
}



export {
  newSingleRackLiningMesh,
  newLeftRackLiningMesh,
  newMiddleRackLiningMesh,
  newRightRackLiningMesh
}