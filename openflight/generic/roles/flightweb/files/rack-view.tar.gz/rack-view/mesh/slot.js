import * as THREE from '../three.module.min.js'

import {
  equipmentPanelWidth,
  uHeight
} from '../spec.js'

import {
} from './three_texture.js'

// geometry
const slotGeometry = new THREE.PlaneGeometry(equipmentPanelWidth, uHeight);

// material
const slotMaterial = new THREE.MeshBasicMaterial({
  'color': 0xFFFFFF
});
slotMaterial.visible = false;

const slotAvailableMaterial = new THREE.MeshPhysicalMaterial({
  'color': 0x4CD694,
  'emissive': 0x4CD694,
  'emissiveIntensity': 0.24,
  'roughness': 0.36,
  'transmission': 1
});

const slotOccupiedMaterial = new THREE.MeshPhysicalMaterial({
  'color': 0xD863BC,
  'emissive': 0xD863BC,
  'emissiveIntensity': 0.24,
  'roughness': 0.36,
  'transmission': 1
});

// mesh
const newSlotMesh = function () {
  return new THREE.Mesh(slotGeometry, slotMaterial);
}

export {
  slotMaterial,
  slotAvailableMaterial,
  slotOccupiedMaterial,
  newSlotMesh
}