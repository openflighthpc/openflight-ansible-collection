import * as THREE from '../three.module.min.js'

import {
  rackRailWidth,
  rackRailHeight,
  rackRailCenterDistanceX
} from '../spec.js'

import {
  leftRackRailTexture,
  leftRackRailRoughnessTexture,
  leftRackRailNormalTexture,
  rightRackRailTexture,
  rightRackRailRoughnessTexture,
  rightRackRailNormalTexture
} from './three_texture.js'

// geometry
const rackRailGeometry = new THREE.PlaneGeometry(rackRailWidth, rackRailHeight);

// material
const leftRackRailMaterial = new THREE.MeshStandardMaterial({
  'color': 0xE1F1FA
});
leftRackRailMaterial.transparent = true;
leftRackRailMaterial.flatShading = true;
leftRackRailMaterial.roughness = 0.72;
leftRackRailMaterial.metalness = 0.84;
leftRackRailMaterial.map = leftRackRailTexture;
leftRackRailMaterial.roughnessMap = leftRackRailRoughnessTexture;
leftRackRailMaterial.normalMap = leftRackRailNormalTexture;

const rightRackRailMaterial = new THREE.MeshStandardMaterial({
  'color': 0xE1F1FA
});
rightRackRailMaterial.transparent = true;
rightRackRailMaterial.flatShading = true;
rightRackRailMaterial.roughness = 0.72;
rightRackRailMaterial.metalness = 0.84;
rightRackRailMaterial.map = rightRackRailTexture;
rightRackRailMaterial.roughnessMap = rightRackRailRoughnessTexture;
rightRackRailMaterial.normalMap = rightRackRailNormalTexture;

// mesh
const newRackRailMesh = function () {
  const groupMesh = new THREE.Group();

    const leftRackRailMesh = new THREE.Mesh(rackRailGeometry, leftRackRailMaterial);
    leftRackRailMesh.position.x = -rackRailCenterDistanceX;
    const rightRackRailMesh = new THREE.Mesh(rackRailGeometry, rightRackRailMaterial);
    rightRackRailMesh.position.x = rackRailCenterDistanceX;

  groupMesh.add(leftRackRailMesh, rightRackRailMesh);

  return groupMesh;
}

export { newRackRailMesh }