import * as THREE from '../three.module.min.js'

import {
  halfRackOuterDepth,
  halfWideRackOuterWidth,
  halfNarrowRackOuterWidth,
  rackEncolsureOuterRadius,
  halfRackInnerWidth,
  rackEnclosureWidePostWidth,
  rackEnclosureNarrowPostWidth,
  rackInnerHeight,
  halfRackInnerHeight,
  halfEquipmentClearance,
  rackEncolsureInnerRadius,
  rackEnclosurePostDepth,
  rackEnclosureBeamDepth
} from '../spec.js'

import {
  rackEnclosurePostLightTexture,
  rackEnclosureWallTexture
} from './three_texture.js'

// geometry
//// enclosure post
////// single rack
const singleRackEnclosurePostShape = new THREE.Shape();
singleRackEnclosurePostShape.moveTo(-halfNarrowRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance);
singleRackEnclosurePostShape.arc(rackEncolsureOuterRadius, 0, rackEncolsureOuterRadius, Math.PI, Math.PI / 2, true);
singleRackEnclosurePostShape.lineTo(halfNarrowRackOuterWidth - rackEncolsureOuterRadius, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
singleRackEnclosurePostShape.arc(0, -rackEncolsureOuterRadius, rackEncolsureOuterRadius, Math.PI / 2, 0, true);
singleRackEnclosurePostShape.lineTo(halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
singleRackEnclosurePostShape.lineTo(-halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));

  const singleRackEnclosurePostHole = new THREE.Path();
  singleRackEnclosurePostHole.moveTo(-halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance);
  singleRackEnclosurePostHole.arc(rackEncolsureInnerRadius, 0, rackEncolsureInnerRadius, Math.PI, Math.PI / 2, true);
  singleRackEnclosurePostHole.lineTo(halfRackInnerWidth - rackEncolsureInnerRadius, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  singleRackEnclosurePostHole.arc(0, -rackEncolsureInnerRadius, rackEncolsureInnerRadius, Math.PI / 2, 0, true);
  singleRackEnclosurePostHole.lineTo(halfRackInnerWidth, -halfRackInnerHeight);
  singleRackEnclosurePostHole.lineTo(-halfRackInnerWidth, -halfRackInnerHeight);

singleRackEnclosurePostShape.holes = [singleRackEnclosurePostHole];

const singleRackPostGeometry = new THREE.ExtrudeGeometry(
  singleRackEnclosurePostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

////// left rack
//////// front
const leftRackEnclosureFrontPostShape = new THREE.Shape();
// top
leftRackEnclosureFrontPostShape.moveTo(-halfNarrowRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance);
leftRackEnclosureFrontPostShape.arc(rackEncolsureOuterRadius, 0, rackEncolsureOuterRadius, Math.PI, Math.PI / 2, true);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
// decoration light trenching
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.8);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.06, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.98);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.06, -halfRackInnerHeight + 1.98);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight + 1.8);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight);
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, -halfRackInnerHeight);
// bottom
leftRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
leftRackEnclosureFrontPostShape.lineTo(-halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));

  // holes
  // equipment space hole
  const leftRackEnclosurePostHole = new THREE.Path();
  leftRackEnclosurePostHole.moveTo(-halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance);
  leftRackEnclosurePostHole.arc(rackEncolsureInnerRadius, 0, rackEncolsureInnerRadius, Math.PI, Math.PI / 2, true);
  leftRackEnclosurePostHole.lineTo(halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  leftRackEnclosurePostHole.lineTo(halfRackInnerWidth, -halfRackInnerHeight);
  leftRackEnclosurePostHole.lineTo(-halfRackInnerWidth, -halfRackInnerHeight);

  // decoration light holes
  const rackEnclosureLeftDecorationLightHole = new THREE.Path ();
  rackEnclosureLeftDecorationLightHole.moveTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight + 1.86);
  rackEnclosureLeftDecorationLightHole.lineTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight + 5.46);
  rackEnclosureLeftDecorationLightHole.lineTo(halfWideRackOuterWidth - 0.12, -halfRackInnerHeight + 5.58);
  rackEnclosureLeftDecorationLightHole.lineTo(halfWideRackOuterWidth - 0.12, -halfRackInnerHeight + 1.98);

leftRackEnclosureFrontPostShape.holes = [
  leftRackEnclosurePostHole,
  rackEnclosureLeftDecorationLightHole
];

const leftRackFrontPostGeometry = new THREE.ExtrudeGeometry(
  leftRackEnclosureFrontPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

//////// back
const leftRackEnclosureBackPostShape = new THREE.Shape();
leftRackEnclosureBackPostShape.moveTo(-halfNarrowRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance);
leftRackEnclosureBackPostShape.arc(rackEncolsureOuterRadius, 0, rackEncolsureOuterRadius, Math.PI, Math.PI / 2, true);
leftRackEnclosureBackPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
leftRackEnclosureBackPostShape.lineTo(halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
leftRackEnclosureBackPostShape.lineTo(-halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
leftRackEnclosureBackPostShape.holes = [leftRackEnclosurePostHole];

const leftRackBackPostGeometry = new THREE.ExtrudeGeometry(
  leftRackEnclosureBackPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

////// middle rack
//////// front
const middleRackEnclosureFrontPostShape = new THREE.Shape();
// top
middleRackEnclosureFrontPostShape.moveTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
// right side decoration light trenching
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.8);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.06, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.98);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.06, -halfRackInnerHeight + 1.98);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight + 1.8);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth - 0.24, -halfRackInnerHeight);
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, -halfRackInnerHeight);
// bottom
middleRackEnclosureFrontPostShape.lineTo(halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
// left side decoration light trenching
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, -halfRackInnerHeight);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight + 1.8);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.06, -halfRackInnerHeight + 1.98);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.06, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.98);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.8);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
middleRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);

  const middleRackEnclosurePostHole = new THREE.Path();
  middleRackEnclosurePostHole.moveTo(-halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  middleRackEnclosurePostHole.lineTo(halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  middleRackEnclosurePostHole.lineTo(halfRackInnerWidth, -halfRackInnerHeight);
  middleRackEnclosurePostHole.lineTo(-halfRackInnerWidth, -halfRackInnerHeight);

  // left side decoration light holes has been defined above for the left rack geometry construction
  // here only the right side decoration light holes need to be defined
  const rackEnclosureRightDecorationLightHole = new THREE.Path ();
  rackEnclosureRightDecorationLightHole.moveTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight + 1.86);
  rackEnclosureRightDecorationLightHole.lineTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight + 5.46);
  rackEnclosureRightDecorationLightHole.lineTo(-halfWideRackOuterWidth + 0.12, -halfRackInnerHeight + 5.58);
  rackEnclosureRightDecorationLightHole.lineTo(-halfWideRackOuterWidth + 0.12, -halfRackInnerHeight + 1.98);

middleRackEnclosureFrontPostShape.holes = [
  middleRackEnclosurePostHole,
  rackEnclosureLeftDecorationLightHole,
  rackEnclosureRightDecorationLightHole,
];

const middleRackFrontPostGeometry = new THREE.ExtrudeGeometry(
  middleRackEnclosureFrontPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

//////// back
const middleRackEnclosureBackPostShape = new THREE.Shape();
middleRackEnclosureBackPostShape.moveTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
middleRackEnclosureBackPostShape.lineTo(halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
middleRackEnclosureBackPostShape.lineTo(halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
middleRackEnclosureBackPostShape.lineTo(-halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
middleRackEnclosureBackPostShape.holes = [middleRackEnclosurePostHole];

const middleRackBackPostGeometry = new THREE.ExtrudeGeometry(
  middleRackEnclosureBackPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

// right rack
//////// front
const rightRackEnclosureFrontPostShape = new THREE.Shape();
// top
rightRackEnclosureFrontPostShape.moveTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
rightRackEnclosureFrontPostShape.lineTo(halfNarrowRackOuterWidth - rackEncolsureOuterRadius, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
rightRackEnclosureFrontPostShape.arc(0, -rackEncolsureOuterRadius, rackEncolsureOuterRadius, Math.PI / 2, 0, true);
// right side
rightRackEnclosureFrontPostShape.lineTo(halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
// bottom
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
// left side decoration light trenching
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, -halfRackInnerHeight);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, -halfRackInnerHeight + 1.8);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.06, -halfRackInnerHeight + 1.98);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.06, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.98);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius - 1.8);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth + 0.24, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
rightRackEnclosureFrontPostShape.lineTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);

  const rightRackEnclosurePostHole = new THREE.Path();
  rightRackEnclosurePostHole.moveTo(-halfRackInnerWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  rightRackEnclosurePostHole.lineTo(halfRackInnerWidth - rackEncolsureInnerRadius, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);
  rightRackEnclosurePostHole.arc(0, -rackEncolsureInnerRadius, rackEncolsureInnerRadius, Math.PI / 2, 0, true);
  rightRackEnclosurePostHole.lineTo(halfRackInnerWidth, -halfRackInnerHeight);
  rightRackEnclosurePostHole.lineTo(-halfRackInnerWidth, -halfRackInnerHeight);

rightRackEnclosureFrontPostShape.holes = [
  rightRackEnclosurePostHole,
  rackEnclosureRightDecorationLightHole
];

const rightRackFrontPostGeometry = new THREE.ExtrudeGeometry(
  rightRackEnclosureFrontPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

//////// back
const rightRackEnclosureBackPostShape = new THREE.Shape();
rightRackEnclosureBackPostShape.moveTo(-halfWideRackOuterWidth, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
rightRackEnclosureBackPostShape.lineTo(halfNarrowRackOuterWidth - rackEncolsureOuterRadius, halfRackInnerHeight + halfEquipmentClearance + rackEncolsureOuterRadius);
rightRackEnclosureBackPostShape.arc(0, -rackEncolsureOuterRadius, rackEncolsureOuterRadius, Math.PI / 2, 0, true);
rightRackEnclosureBackPostShape.lineTo(halfNarrowRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
rightRackEnclosureBackPostShape.lineTo(-halfWideRackOuterWidth, -(halfRackInnerHeight + rackEnclosureNarrowPostWidth));
rightRackEnclosureBackPostShape.holes = [rightRackEnclosurePostHole];

const rightRackBackPostGeometry = new THREE.ExtrudeGeometry(
  rightRackEnclosureBackPostShape,
  {
    'depth': rackEnclosurePostDepth,
    'bevelEnabled': false,
  }
);

//// enclosure post light
const rackEncosurePostLightGeometry = new THREE.PlaneGeometry(0.48, rackInnerHeight + halfEquipmentClearance + rackEncolsureInnerRadius);

//// enclosure beam
////// rounded enclosure beam
/**
 * This shape is used for the rounded corners of the applicable enclosures, i.e. single rack enclosure, enclosure of the leftmost rack, and enclosure of the rightmost rack.
 */
const roundedEnclosureBeamShape = new THREE.Shape();
roundedEnclosureBeamShape.moveTo(0, 0);
roundedEnclosureBeamShape.arc(rackEncolsureOuterRadius, 0, rackEncolsureOuterRadius, Math.PI, Math.PI / 2, true);
roundedEnclosureBeamShape.lineTo(rackEncolsureOuterRadius, rackEncolsureInnerRadius);
roundedEnclosureBeamShape.arc(0, -rackEncolsureInnerRadius, rackEncolsureInnerRadius, Math.PI / 2, Math.PI);

const roundedEnclosureBeamGeometry = new THREE.ExtrudeGeometry(
  roundedEnclosureBeamShape,
  {
    'depth': rackEnclosureBeamDepth,
    'bevelEnabled': false,
  }
);

////// narrow enclosure beam
const narrowEnclosureBeamGeometry = new THREE.BoxGeometry(rackEnclosureNarrowPostWidth, rackEnclosureNarrowPostWidth, rackEnclosureBeamDepth);

////// wide enclosure beam
const wideEnclosureBeamGeometry = new THREE.BoxGeometry(rackEnclosureWidePostWidth, rackEnclosureNarrowPostWidth, rackEnclosureBeamDepth);

////// wide right angle enclosure beam
/**
 * This shape is used for the right angle corners of the applicable enclosures, i.e. enclosures of a non-single-rack cluster.
 */
const rightAngleEnclosureBeamShape = new THREE.Shape();
rightAngleEnclosureBeamShape.moveTo(halfRackInnerWidth - halfWideRackOuterWidth, 0);
rightAngleEnclosureBeamShape.lineTo(halfRackInnerWidth - halfWideRackOuterWidth, rackEncolsureOuterRadius);
rightAngleEnclosureBeamShape.lineTo(0, rackEncolsureOuterRadius);
rightAngleEnclosureBeamShape.lineTo(0, rackEncolsureInnerRadius);
rightAngleEnclosureBeamShape.lineTo(halfNarrowRackOuterWidth - halfWideRackOuterWidth, rackEncolsureInnerRadius);
rightAngleEnclosureBeamShape.lineTo(halfNarrowRackOuterWidth - halfWideRackOuterWidth, 0);

const rightAngleEnclosureBeamGeometry = new THREE.ExtrudeGeometry(
  rightAngleEnclosureBeamShape,
  {
    'depth': rackEnclosureBeamDepth,
    'bevelEnabled': false,
  }
);

//// enclosure wall
const rackEnclosureWallGeometry = new THREE.PlaneGeometry(rackEnclosureBeamDepth, rackInnerHeight + halfEquipmentClearance);


// material
//// enclosure frame wire
/**
 * This material is used for the enclosure frame wire components, including posts and beams
 */
const rackEnclosureFrameWireMaterial = new THREE.MeshStandardMaterial({
  'color': 0xE1F1FA
});
rackEnclosureFrameWireMaterial.side = THREE.DoubleSide;
rackEnclosureFrameWireMaterial.roughness = 0.24;
rackEnclosureFrameWireMaterial.metalness = 0.96;

//// enclosure post light
const rackEnclosurePostLightMaterial = new THREE.MeshBasicMaterial({
  'color': 0xFFFFFF
});
rackEnclosurePostLightMaterial.side = THREE.DoubleSide;
rackEnclosurePostLightMaterial.map = rackEnclosurePostLightTexture;

//// enclosure wall
const rackEnclosureWallMaterial = new THREE.MeshStandardMaterial({
  'color': 0xFFFFFF
});
rackEnclosureWallMaterial.side = THREE.DoubleSide;
rackEnclosureWallMaterial.transparent = true;
rackEnclosureWallMaterial.flatShading = true;
rackEnclosureWallMaterial.roughness = 0.24;
rackEnclosureWallMaterial.metalness = 0.96;
rackEnclosureWallMaterial.map = rackEnclosureWallTexture;

// mesh
//// enclosure post
////// single rack
const newSingleRackPostMesh = function () {
  return new THREE.Mesh(singleRackPostGeometry, rackEnclosureFrameWireMaterial);
}

////// left rack
//////// front
const newLeftRackFrontPostMesh = function () {
  return new THREE.Mesh(leftRackFrontPostGeometry, rackEnclosureFrameWireMaterial);
}
//////// back
const newLeftRackBackPostMesh = function () {
  return new THREE.Mesh(leftRackBackPostGeometry, rackEnclosureFrameWireMaterial);
}

////// middle rack
//////// front
const newMiddleRackFrontPostMesh = function () {
  return new THREE.Mesh(middleRackFrontPostGeometry, rackEnclosureFrameWireMaterial);
}

//////// back
const newMiddleRackBackPostMesh = function () {
  return new THREE.Mesh(middleRackBackPostGeometry, rackEnclosureFrameWireMaterial);
}

////// right rack
const newRightRackFrontPostMesh = function () {
  return new THREE.Mesh(rightRackFrontPostGeometry, rackEnclosureFrameWireMaterial);
}

const newRightRackBackPostMesh = function () {
  return new THREE.Mesh(rightRackBackPostGeometry, rackEnclosureFrameWireMaterial);
}

//// enclosure post light
const newRackEnclosurePostLightMesh = function () {
  return new THREE.Mesh(rackEncosurePostLightGeometry, rackEnclosurePostLightMaterial);
}

//// enclosure beam
////// rounded enclosure beam
const newRoundedEnclosureBeamMesh = function () {
  return new THREE.Mesh(roundedEnclosureBeamGeometry, rackEnclosureFrameWireMaterial);
}

////// right angle enclosure beam
const newRightAngleRackEnclosureBeamMesh = function () {
  return new THREE.Mesh(rightAngleEnclosureBeamGeometry, rackEnclosureFrameWireMaterial);
}

////// narrow enclosure beam
const newNarrowRackEnclosureBeamMesh = function () {
  return new THREE.Mesh(narrowEnclosureBeamGeometry, rackEnclosureFrameWireMaterial);
}

////// wide enclosure beam
const newWideRackEnclosureBeamMesh = function () {
  return new THREE.Mesh(wideEnclosureBeamGeometry, rackEnclosureFrameWireMaterial);
}

////// narrow enclosure beam
const newRackEnclosureWallMesh = function () {
  return new THREE.Mesh(rackEnclosureWallGeometry, rackEnclosureWallMaterial);
}

//// entire enclosure
///// single rack
const newSingleRackEnclosureMesh = function () {
  const groupMesh = new THREE.Group();

    const frontPostMesh = newSingleRackPostMesh();
    frontPostMesh.position.z = halfRackOuterDepth - rackEnclosurePostDepth;

    const backPostMesh = newSingleRackPostMesh();
    backPostMesh.position.z = -halfRackOuterDepth;

    const topLeftBeamMesh = newRoundedEnclosureBeamMesh();
    topLeftBeamMesh.position.x = -halfNarrowRackOuterWidth;
    topLeftBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topLeftBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    
    const topRightBeamMesh = newRoundedEnclosureBeamMesh();
    topRightBeamMesh.position.x = halfNarrowRackOuterWidth;
    topRightBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topRightBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    topRightBeamMesh.scale.x = -1;

    const bottomLeftBeamMesh = newNarrowRackEnclosureBeamMesh();
    bottomLeftBeamMesh.position.x = -halfNarrowRackOuterWidth + rackEnclosureNarrowPostWidth / 2;
    bottomLeftBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);
    
    const bottomRightBeamMesh = newNarrowRackEnclosureBeamMesh();
    bottomRightBeamMesh.position.x = halfNarrowRackOuterWidth - rackEnclosureNarrowPostWidth / 2;
    bottomRightBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);

    const leftWallMesh = newRackEnclosureWallMesh();
    leftWallMesh.position.x = -halfNarrowRackOuterWidth;
    leftWallMesh.position.y = halfEquipmentClearance / 2;
    leftWallMesh.rotation.y = Math.PI / -2;

    const rightWallMesh = newRackEnclosureWallMesh();
    rightWallMesh.position.x = halfNarrowRackOuterWidth;
    rightWallMesh.position.y = halfEquipmentClearance / 2;
    rightWallMesh.rotation.y = Math.PI / 2;

  groupMesh.add(
    frontPostMesh,
    backPostMesh,
    topLeftBeamMesh,
    topRightBeamMesh,
    bottomLeftBeamMesh,
    bottomRightBeamMesh,
    leftWallMesh,
    rightWallMesh
  );

  return groupMesh;
}

// left rack
const newLeftRackEnclosureMesh = function () {
  const groupMesh = new THREE.Group();

    const frontPostMesh = newLeftRackFrontPostMesh();
    frontPostMesh.position.z = halfRackOuterDepth - rackEnclosurePostDepth;

    const postLightMesh = newRackEnclosurePostLightMesh();
    postLightMesh.position.x = halfWideRackOuterWidth;
    postLightMesh.position.y =  (halfEquipmentClearance + rackEncolsureInnerRadius) / 2
    postLightMesh.position.z = halfRackOuterDepth - 0.12;

    const backPostMesh = newLeftRackBackPostMesh();
    backPostMesh.position.z = -halfRackOuterDepth;

    const topLeftBeamMesh = newRoundedEnclosureBeamMesh();
    topLeftBeamMesh.position.x = -halfNarrowRackOuterWidth;
    topLeftBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topLeftBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    
    const topRightBeamMesh = newRightAngleRackEnclosureBeamMesh();
    topRightBeamMesh.position.x = halfWideRackOuterWidth;
    topRightBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topRightBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;

    const bottomLeftBeamMesh = newNarrowRackEnclosureBeamMesh();
    bottomLeftBeamMesh.position.x = -halfNarrowRackOuterWidth + rackEnclosureNarrowPostWidth / 2;
    bottomLeftBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);
    
    const bottomRightBeamMesh = newWideRackEnclosureBeamMesh();
    bottomRightBeamMesh.position.x = halfWideRackOuterWidth - rackEnclosureWidePostWidth / 2;
    bottomRightBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);

    const leftWallMesh = newRackEnclosureWallMesh();
    leftWallMesh.position.x = -halfNarrowRackOuterWidth;
    leftWallMesh.position.y = halfEquipmentClearance / 2;
    leftWallMesh.rotation.y = Math.PI / -2;

    const rightWallMesh = newRackEnclosureWallMesh();
    rightWallMesh.position.x = halfNarrowRackOuterWidth;
    rightWallMesh.position.y = halfEquipmentClearance / 2;
    rightWallMesh.rotation.y = Math.PI / 2;

  groupMesh.add(
    frontPostMesh,
    postLightMesh,
    backPostMesh,
    topLeftBeamMesh,
    topRightBeamMesh,
    bottomLeftBeamMesh,
    bottomRightBeamMesh,
    leftWallMesh,
    rightWallMesh
  );

  return groupMesh;
}

// middle rack
const newMiddleRackEnclosureMesh = function () {
  const groupMesh = new THREE.Group();

    const frontPostMesh = newMiddleRackFrontPostMesh();
    frontPostMesh.position.z = halfRackOuterDepth - rackEnclosurePostDepth;

    const postLightMesh = newRackEnclosurePostLightMesh();
    postLightMesh.position.x = halfWideRackOuterWidth;
    postLightMesh.position.y =  (halfEquipmentClearance + rackEncolsureInnerRadius) / 2
    postLightMesh.position.z = halfRackOuterDepth - 0.12;

    const backPostMesh = newMiddleRackBackPostMesh();
    backPostMesh.position.z = -halfRackOuterDepth;

    const topLeftBeamMesh = newRightAngleRackEnclosureBeamMesh();
    topLeftBeamMesh.position.x = -halfWideRackOuterWidth;
    topLeftBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topLeftBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    topLeftBeamMesh.scale.x = -1;
    
    const topRightBeamMesh = newRightAngleRackEnclosureBeamMesh();
    topRightBeamMesh.position.x = halfWideRackOuterWidth;
    topRightBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topRightBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;

    const bottomLeftBeamMesh = newWideRackEnclosureBeamMesh();
    bottomLeftBeamMesh.position.x = -halfWideRackOuterWidth + rackEnclosureWidePostWidth / 2;
    bottomLeftBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);
    
    const bottomRightBeamMesh = newWideRackEnclosureBeamMesh();
    bottomRightBeamMesh.position.x = halfWideRackOuterWidth - rackEnclosureWidePostWidth / 2;
    bottomRightBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);

    const leftWallMesh = newRackEnclosureWallMesh();
    leftWallMesh.position.x = -halfNarrowRackOuterWidth;
    leftWallMesh.position.y = halfEquipmentClearance / 2;
    leftWallMesh.rotation.y = Math.PI / -2;

    const rightWallMesh = newRackEnclosureWallMesh();
    rightWallMesh.position.x = halfNarrowRackOuterWidth;
    rightWallMesh.position.y = halfEquipmentClearance / 2;
    rightWallMesh.rotation.y = Math.PI / 2;

  groupMesh.add(
    frontPostMesh,
    postLightMesh,
    backPostMesh,
    topLeftBeamMesh,
    topRightBeamMesh,
    bottomLeftBeamMesh,
    bottomRightBeamMesh,
    leftWallMesh,
    rightWallMesh
  );

  return groupMesh;
}

// right rack
const newRightRackEnclosureMesh = function () {
  const groupMesh = new THREE.Group();

    const frontPostMesh = newRightRackFrontPostMesh();
    frontPostMesh.position.z = halfRackOuterDepth - rackEnclosurePostDepth;

    const backPostMesh = newRightRackBackPostMesh();
    backPostMesh.position.z = -halfRackOuterDepth;

    const topLeftBeamMesh = newRightAngleRackEnclosureBeamMesh();
    topLeftBeamMesh.position.x = -halfWideRackOuterWidth;
    topLeftBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topLeftBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    topLeftBeamMesh.scale.x = -1;
    
    const topRightBeamMesh = newRoundedEnclosureBeamMesh();
    topRightBeamMesh.position.x = halfNarrowRackOuterWidth;
    topRightBeamMesh.position.y = halfRackInnerHeight + halfEquipmentClearance;
    topRightBeamMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth;
    topRightBeamMesh.scale.x = -1;

    const bottomLeftBeamMesh = newWideRackEnclosureBeamMesh();
    bottomLeftBeamMesh.position.x = -halfWideRackOuterWidth + rackEnclosureWidePostWidth / 2;
    bottomLeftBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);
    
    const bottomRightBeamMesh = newNarrowRackEnclosureBeamMesh();
    bottomRightBeamMesh.position.x = halfNarrowRackOuterWidth - rackEnclosureNarrowPostWidth / 2;
    bottomRightBeamMesh.position.y = - (halfRackInnerHeight + rackEnclosureNarrowPostWidth / 2);

    const leftWallMesh = newRackEnclosureWallMesh();
    leftWallMesh.position.x = -halfNarrowRackOuterWidth;
    leftWallMesh.position.y = halfEquipmentClearance / 2;
    leftWallMesh.rotation.y = Math.PI / -2;

    const rightWallMesh = newRackEnclosureWallMesh();
    rightWallMesh.position.x = halfNarrowRackOuterWidth;
    rightWallMesh.position.y = halfEquipmentClearance / 2;
    rightWallMesh.rotation.y = Math.PI / 2;

  groupMesh.add(
    frontPostMesh,
    backPostMesh,
    topLeftBeamMesh,
    topRightBeamMesh,
    bottomLeftBeamMesh,
    bottomRightBeamMesh,
    leftWallMesh,
    rightWallMesh
  );

  return groupMesh;
}

export {
  newSingleRackEnclosureMesh,
  newLeftRackEnclosureMesh,
  newMiddleRackEnclosureMesh,
  newRightRackEnclosureMesh
}