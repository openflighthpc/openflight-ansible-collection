import * as THREE from '../three.module.min.js'

import {
  halfHardDriveBayWidth,
  hardDriveBayRadius,
  hardDriveBayDepth,
  decorationLightRadius,
  halfHardDriveBayHeight,
  equipmentContentHorizontalPadding,
  decorationLightDepth,
  hardDriveBayHeight
} from '../spec.js'

import {
  nodePanelDecorationLightBlueTexture,
  nodePanelDecorationLightYellowTexture,
} from './three_texture.js'
import { nodePanelDecorationLightBlueMaterial, nodePanelDecorationLightYellowMaterial } from './node.js';

// geometry
//// frame
const hardDriveBayFrameShape = new THREE.Shape();
hardDriveBayFrameShape.moveTo(-halfHardDriveBayWidth, halfHardDriveBayHeight - hardDriveBayRadius);
hardDriveBayFrameShape.arc(hardDriveBayRadius, 0, hardDriveBayRadius, Math.PI, Math.PI / 2, true);
hardDriveBayFrameShape.lineTo(halfHardDriveBayWidth - hardDriveBayRadius, halfHardDriveBayHeight);
hardDriveBayFrameShape.arc(0, -hardDriveBayRadius, hardDriveBayRadius, Math.PI / 2, 0, true);
hardDriveBayFrameShape.lineTo(halfHardDriveBayWidth, -halfHardDriveBayHeight + hardDriveBayRadius);
hardDriveBayFrameShape.arc(-hardDriveBayRadius, 0, hardDriveBayRadius, 0, Math.PI / -2, true);
hardDriveBayFrameShape.lineTo(-halfHardDriveBayWidth + hardDriveBayRadius, -halfHardDriveBayHeight);
hardDriveBayFrameShape.arc(0, hardDriveBayRadius, hardDriveBayRadius, 3 * Math.PI / 2, Math.PI, true);

  const ventsGap = 0.018;
  const ventsWidth = 0.18;
  const ventsHeight = (hardDriveBayHeight - 3 * ventsGap) / 6;
  let hardDriveBayVentsHoles = [];
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 4; j++) {
      const hole = new THREE.Path();
      hole.moveTo(-halfHardDriveBayWidth + equipmentContentHorizontalPadding + (ventsWidth + ventsGap) * i, halfHardDriveBayHeight - (ventsHeight + ventsGap) * j - ventsHeight);
      hole.lineTo(-halfHardDriveBayWidth + equipmentContentHorizontalPadding + ventsWidth + (ventsWidth + ventsGap) * i, halfHardDriveBayHeight - (ventsHeight + ventsGap) * j - ventsHeight);
      hole.lineTo(-halfHardDriveBayWidth + equipmentContentHorizontalPadding + ventsWidth + (ventsWidth + ventsGap) * i, halfHardDriveBayHeight - (ventsHeight + ventsGap) * j - 2 * ventsHeight);
      hole.lineTo(-halfHardDriveBayWidth + equipmentContentHorizontalPadding + (ventsWidth + ventsGap) * i, halfHardDriveBayHeight - (ventsHeight + ventsGap) * j - 2 * ventsHeight);
      hardDriveBayVentsHoles.push(hole);
    }
  }
  const hardDriveBayDecorationLightHole = new THREE.Path();
  hardDriveBayDecorationLightHole.moveTo(halfHardDriveBayWidth - equipmentContentHorizontalPadding - decorationLightRadius, decorationLightRadius);
  hardDriveBayDecorationLightHole.arc(0, -decorationLightRadius, decorationLightRadius, 0, 2 * Math.PI, true);

hardDriveBayFrameShape.holes = [
  ...hardDriveBayVentsHoles,
  hardDriveBayDecorationLightHole
];

const hardDriveBayFrameGeometry = new THREE.ExtrudeGeometry(
  hardDriveBayFrameShape,
  {
    'depth': hardDriveBayDepth,
    'bevelEnabled': false,
  }
);

//// vents lining
const hardDriveBayVentsLiningGeometry = new THREE.PlaneGeometry(3 * ventsWidth + 2 * ventsGap, 4 * ventsHeight + 3 * ventsGap);

//// decoration light
const hardDriveBayDecorationLightGeometry = new THREE.PlaneGeometry(2 * decorationLightRadius, 2 * decorationLightRadius);



// material
//// common material
const hardDriveBayFrameMaterial = new THREE.MeshStandardMaterial({
  'side': THREE.DoubleSide,
  'color': 0x517C9C,
  'roughness': 0.24,
  'metalness': 0.6
});

//// vents lining
const hardDriveBayVentsLiningMaterial = new THREE.MeshBasicMaterial({
  'side': THREE.DoubleSide,
  'color': 0x000000
});

// mesh
//// frame
const newHardDriveBayFrameMesh = function () {
  return new THREE.Mesh(hardDriveBayFrameGeometry, hardDriveBayFrameMaterial);
}

//// vents lining
const newHardDriveBayVentsLiningMesh = function () {
  return new THREE.Mesh(hardDriveBayVentsLiningGeometry, hardDriveBayVentsLiningMaterial);
}

//// decoration light
////// blue light
const newHardDriveBayDecorationLightBlueMesh = function () {
  return new THREE.Mesh(hardDriveBayDecorationLightGeometry, nodePanelDecorationLightBlueMaterial);
}
////// yellow light
const newHardDriveBayDecorationLightYellowMesh = function () {
  return new THREE.Mesh(hardDriveBayDecorationLightGeometry, nodePanelDecorationLightYellowMaterial);
}

const newHardDriveBayMesh = function (decorationLightColor) {
  const groupMesh = new THREE.Group();

    const frameMesh = newHardDriveBayFrameMesh();

    const liningMesh = newHardDriveBayVentsLiningMesh();
    liningMesh.position.x = -halfHardDriveBayWidth + equipmentContentHorizontalPadding + (3 * ventsWidth + 2 * ventsGap) / 2;
    liningMesh.position.z = hardDriveBayDepth - decorationLightDepth;

    let lightMesh;
    if (decorationLightColor === 'blue') {
      lightMesh = newHardDriveBayDecorationLightBlueMesh();
    } else if (decorationLightColor === 'yellow') {
      lightMesh = newHardDriveBayDecorationLightYellowMesh();
    }
    lightMesh.position.x = halfHardDriveBayWidth - equipmentContentHorizontalPadding - decorationLightRadius;
    lightMesh.position.z = hardDriveBayDepth - decorationLightDepth;

  groupMesh.add(frameMesh, liningMesh, lightMesh);
  groupMesh.userData.interactiveChildren = {
    "hardDriveBayFrameMesh": frameMesh,
    "hardDriveBayLiningMesh": liningMesh,
    "decorationLightMesh": lightMesh
  };

  return groupMesh;
}

export {
  hardDriveBayFrameMaterial,
  hardDriveBayVentsLiningMaterial,
  newHardDriveBayMesh
}