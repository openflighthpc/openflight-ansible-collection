import * as THREE from '../three.module.min.js'

import {
  floorTileWidth,
  floorTileDepth,
  halfFloorTileWidth,
  halfFloorTileDepth,
  roomHeight,
  halfRoomHeight
} from '../spec.js'

import {
} from './three_texture.js'

// geometry
//// side wall
const newSideWallGeometry = function (roomVerticalTileNumber) {
  return new THREE.PlaneGeometry((roomVerticalTileNumber + 3) * floorTileDepth, roomHeight);
}

//// back wall
const newBackWallGeometry = function (roomHorizontalTileNumber) {
  return new THREE.PlaneGeometry((roomHorizontalTileNumber + 3) * floorTileWidth, roomHeight);
}



// material
//// general wall material
const wallMaterial = new THREE.MeshStandardMaterial({
  'color': 0x2895D7,
  'roughness': 0.5,
  'metalness': 0.2
});


// mesh
// left wall
const newLeftWallMesh = function (roomVerticalTileNumber) {
  const mesh = new THREE.Mesh(newSideWallGeometry(roomVerticalTileNumber), wallMaterial);
  mesh.rotation.y = Math.PI / 2;
  return mesh;
}

// right wall
const newRightWallMesh = function (roomVerticalTileNumber) {
  const mesh = new THREE.Mesh(newSideWallGeometry(roomVerticalTileNumber), wallMaterial);
  mesh.rotation.y = Math.PI / -2;
  return mesh;
}

// back wall
const newBackWallMesh = function (roomHorizontalTileNumber) {
  const mesh = new THREE.Mesh(newBackWallGeometry(roomHorizontalTileNumber), wallMaterial);
  return mesh;
}

// all the walls
const newWallMesh = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const groupMesh = new THREE.Group();

    const leftWallMesh = newLeftWallMesh(roomVerticalTileNumber);
    leftWallMesh.position.x = - (roomHorizontalTileNumber + 3) * halfFloorTileWidth;
    leftWallMesh.position.y = halfRoomHeight;

    const rightWallMesh = newRightWallMesh(roomVerticalTileNumber);
    rightWallMesh.position.x = (roomHorizontalTileNumber + 3) * halfFloorTileWidth;
    rightWallMesh.position.y = halfRoomHeight;
    
    const backWallMesh = newBackWallMesh(roomHorizontalTileNumber);
    backWallMesh.position.y = halfRoomHeight;
    backWallMesh.position.z = - (roomVerticalTileNumber + 3) * halfFloorTileDepth;

  groupMesh.add(leftWallMesh, rightWallMesh, backWallMesh);
  return groupMesh;
}

export { newWallMesh }