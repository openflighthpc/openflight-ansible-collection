import * as THREE from '../three.module.min.js'

import {
  floorTileWidth,
  floorTileDepth,
} from '../spec.js'

import {
    newFloorTexture,
    newFloorNormalTexture,
    newFloorRoughnessTexture
} from './three_texture.js'

// geometry
const newFloorGeometry = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  return new THREE.PlaneGeometry((roomHorizontalTileNumber + 3) * floorTileWidth, (roomVerticalTileNumber + 3) * floorTileDepth);
}



// material
const newFloorMaterial = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const material  = new THREE.MeshPhysicalMaterial();
  material.roughness = 0.24;
  material.flatShading = true;
  material.map = newFloorTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  material.roughnessMap = newFloorRoughnessTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  material.normalMap = newFloorNormalTexture(roomHorizontalTileNumber, roomVerticalTileNumber);
  material.normalScale = new THREE.Vector2(0.6, 0.6);
  material.envMapIntensity = 0.48;
  material.reflectivity = 0.96;
  return material
}



// mesh
const newFloorMesh = function (roomHorizontalTileNumber, roomVerticalTileNumber) {
  const mesh = new THREE.Mesh(
    newFloorGeometry(roomHorizontalTileNumber, roomVerticalTileNumber),
    newFloorMaterial(roomHorizontalTileNumber, roomVerticalTileNumber)
  );
  mesh.rotation.x = - Math.PI / 2;
  return mesh;
}

export { newFloorMesh }