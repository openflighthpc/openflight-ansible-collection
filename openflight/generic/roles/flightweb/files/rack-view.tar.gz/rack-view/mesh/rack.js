import * as THREE from '../three.module.min.js'

import {
  rackInnerHeight,
  halfRackInnerHeight,
  rackEnclosureNarrowPostWidth,
  halfRackLiningHeight,
  halfEquipmentClearance,
  halfRackOuterDepth,
  rackEnclosurePostDepth,
  equipmentPanelDepth
} from '../spec.js'

import {
  newSingleRackEnclosureMesh,
  newSingleRackLiningMesh,
  newLeftRackEnclosureMesh,
  newLeftRackLiningMesh,
  newMiddleRackEnclosureMesh,
  newMiddleRackLiningMesh,
  newRightRackEnclosureMesh,
  newRightRackLiningMesh,
  newRackRailMesh
} from '../mesh.js'

// mesh
//// single rack
const newSingleRackMesh = function () {
  const groupMesh = new THREE.Group();

    const rackRailMesh = newRackRailMesh();
    rackRailMesh.position.z = 3;
    rackRailMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackEnclosureMesh = newSingleRackEnclosureMesh();
    rackEnclosureMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackLiningMesh = newSingleRackLiningMesh();
    rackLiningMesh.position.y = rackInnerHeight + halfEquipmentClearance + rackEnclosureNarrowPostWidth;
    rackLiningMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth - equipmentPanelDepth;
  
  groupMesh.add(rackRailMesh, rackEnclosureMesh, rackLiningMesh);
  return groupMesh;
}

//// left rack
const newLeftRackMesh = function () {
  const groupMesh = new THREE.Group();

    const rackRailMesh = newRackRailMesh();
    rackRailMesh.position.z = 3;
    rackRailMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackEnclosureMesh = newLeftRackEnclosureMesh();
    rackEnclosureMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackLiningMesh = newLeftRackLiningMesh();
    rackLiningMesh.position.y = rackInnerHeight + halfEquipmentClearance + rackEnclosureNarrowPostWidth;
    rackLiningMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth - equipmentPanelDepth;
  
  groupMesh.add(rackRailMesh, rackEnclosureMesh, rackLiningMesh);
  return groupMesh;
}

//// middle rack
const newMiddleRackMesh = function () {
  const groupMesh = new THREE.Group();

    const rackRailMesh = newRackRailMesh();
    rackRailMesh.position.z = halfRackOuterDepth - rackEnclosurePostDepth;
    rackRailMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackEnclosureMesh = newMiddleRackEnclosureMesh();
    rackEnclosureMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackLiningMesh = newMiddleRackLiningMesh();
    rackLiningMesh.position.y = rackInnerHeight + halfEquipmentClearance + rackEnclosureNarrowPostWidth + halfRackLiningHeight;
  
  groupMesh.add(rackRailMesh, rackEnclosureMesh, rackLiningMesh);
  return groupMesh;
}

//// right rack
const newRightRackMesh = function () {
  const groupMesh = new THREE.Group();

    const rackRailMesh = newRackRailMesh();
    rackRailMesh.position.z = 3;
    rackRailMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackEnclosureMesh = newRightRackEnclosureMesh();
    rackEnclosureMesh.position.y = halfRackInnerHeight + rackEnclosureNarrowPostWidth;

    const rackLiningMesh = newRightRackLiningMesh();
    rackLiningMesh.position.y = rackInnerHeight + halfEquipmentClearance + rackEnclosureNarrowPostWidth;
    rackLiningMesh.position.z = -halfRackOuterDepth + rackEnclosurePostDepth - equipmentPanelDepth;
  
  groupMesh.add(rackRailMesh, rackEnclosureMesh, rackLiningMesh);
  return groupMesh;
}


export { 
  newSingleRackMesh,
  newLeftRackMesh,
  newMiddleRackMesh,
  newRightRackMesh
};