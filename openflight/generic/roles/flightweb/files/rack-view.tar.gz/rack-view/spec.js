export const cameraFOV = 60;
export const defaultCameraPositionY = 10.8;
/**
 * This variable specifies the expected default ratio of the outer height of the rack to
 * the height of the entire field of view.
 */
export const defaultCameraViewRackOuterHeightRatio = 1.2;
export const cameraVerticalPanRange = 4; // half range i.e. from 12 to 16 or from 12 to 8
export const cameraPanTransitionDuration = 0.72;
/**
 * The height of the room.
 */
export const roomHeight = 30;
/**
 * The wide type outer width of the rack.
 * 
 * To visually create the gap between clusters, 2 types of the rack outer width, wide and narrow, are specified to form 4 types of the rack:
 * 1. For the rack of a single-rack cluster, the outer width is narrow.
 * 2. For the leftmost rack of a multi-rack cluster, the outer width consists of half narrow width for the left half and half wide width for the right half.
 * 3. For the middle rack of a multi-rack cluster, ther outer width is wide.
 * 4. For the rightmost rack of a multi-rack cluster, the outer width consists of half wide width for the left half and half narrow width for the right half.
 */
export const wideRackOuterWidth = 8;
/**
 * The narrow type outer width of the rack.
 * 
 * To visually create the gap between clusters, 2 types of the rack outer width, wide and narrow, are specified to form 4 types of the rack:
 * 1. For the rack of a single-rack cluster, the outer width is narrow.
 * 2. For the leftmost rack of a multi-rack cluster, the outer width consists of half narrow width for the left half and half wide width for the right half.
 * 3. For the middle rack of a multi-rack cluster, ther outer width is wide.
 * 4. For the rightmost rack of a multi-rack cluster, the outer width consists of half wide width for the left half and half narrow width for the right half.
 */
export const narrowRackOuterWidth = 6;
/**
 * The outer depth of the rack
 */
export const rackOuterDepth = 8;
/**
 * The available inner width of the rack.
 */
export const rackInnerWidth = 4.826;
/**
 * The width of the rack rail
 */
export const rackRailWidth = 0.15875;
/**
 * The height of 1u, i.e. the height of each slot of the rack.
 */
export const uHeight = 0.4445;
/**
 * The depth of the equipment body, i.e. server node body.
 * 
 * The depth of the front panel of the equipment, which is used for mounting the node on the rails, is not included.
 */
export const equipmentBodyDepth = 6;
/**
 * The depth of the equipment panel, i.e. server node panel.
 */
export const equipmentPanelDepth = 0.22225;
/**
 * The redundant gap between equipments based on realistic engineering assemply considerations.
 */
export const equipmentClearance = 0.00794;
/**
 * The distance of the equipment on z axis from its normal position to its grabbed position.
 */
export const equipmentLiftDistanceZ = 2.4;
/**
 * The transition time of the equipment from its normal position to its grabbed position.
 */
export const equipmentLiftTransitionDuration = 0.36;
/**
 * The transition time of the equipment from its normal position to its grabbed position.
 */
export const equipmentPulloutTransitionDuration = 0.48;
/**
 * The transition time of the equipment from its current position to its normal position.
 */
export const equipmentPushinTransitionDuration = 0.6;
/**
 * The decorative outer border radius of the applicable rack enclosure.
 */
export const rackEncolsureOuterRadius = 1.2;
/**
 * The depth distance from the slot indicator mesh to the front panel surface of the equipment.
 */
export const slotDistanceZ = 0.12;
/**
 * The width of a hard drive bay.
 */
export const hardDriveBayWidth = 1.016;
/**
 * The height of a hard drive bay.
 */
export const hardDriveBayHeight = 0.254;
/**
 * The depth of a hard drive bay.
 */
export const hardDriveBayDepth = 1.4605;
/**
 * The height of a hard drive bay.
 */
export const hardDriveBayRadius = 0.024;
/**
 * The radius of the small decorative LED Light bulbs on the equipment.
 */
export const decorationLightRadius = 0.0513;
/**
 * The depth of the recess of the small decorative LED Light bulbs relative to the front surface.
 */
export const decorationLightDepth = 0.036;
/**
 * The horizontal white spacing of the equipment.
 */
export const equipmentContentHorizontalPadding = 0.12;
/**
 * The veritical white spacing of the equipment.
 */
export const equipmentContentVerticalPadding = 0.084;
/**
 * The cold rolled steel plate wall thickness of the equipment chassis.
 */
export const equipmentChassisWallThickness = 0.015;
/**
 * The width of the status light of the storage node.
 */
export const storageNodeStatusLightWidth = 0.15;
/**
 * The halved height of the room.
 */
export const halfRoomHeight = roomHeight / 2;
/**
 * The width of the floor tile.
 */
export const floorTileWidth = wideRackOuterWidth;
/**
* The halved width of the floor tile.
*/
export const halfFloorTileWidth = floorTileWidth / 2;
/**
 * The depth of the floor tile.
 */
export const floorTileDepth = rackOuterDepth;
/**
* The halved depth of the floor tile.
*/
export const halfFloorTileDepth = floorTileDepth / 2;
/**
 * The halved wide type outer width of the rack.
 */
export const halfWideRackOuterWidth = wideRackOuterWidth / 2;
/**
 * The halved narrow type outer width of the rack.
 */
export const halfNarrowRackOuterWidth = narrowRackOuterWidth / 2;
/**
 * The halved outer depth of the rack
 */
export const halfRackOuterDepth = rackOuterDepth / 2;
/**
 * The halved available inner width of the rack.
 */
export const halfRackInnerWidth = rackInnerWidth / 2;
/**
 * The enclosure post width of the wide type rack.
 */
export const rackEnclosureWidePostWidth = halfWideRackOuterWidth - halfRackInnerWidth;
/**
 * The enclosure post width of the narrow type rack.
 */
export const rackEnclosureNarrowPostWidth = halfNarrowRackOuterWidth - halfRackInnerWidth;
/**
 * The halved width of the rack rail.
 */
export const halfRackRailWidth = rackRailWidth / 2;
/**
 * The absolute horizontal distance from the center of the rack to the center of the rack rail.
 */
export const rackRailCenterDistanceX = halfRackInnerWidth - halfRackRailWidth;
/**
 * The available inner height of a 42u rack.
 * 
 * The heights of the decorative inner components and redundant spaces, e.g. the rack lining, are not included.
 */
export const rackInnerHeight = uHeight * 42;
/**
 * The halved available inner height of the rack.
 */
export const halfRackInnerHeight = rackInnerHeight / 2;
/**
 * The height of the rack rail.
 */
export const rackRailHeight = rackInnerHeight;
/**
 * The halved height of 1u.
 */
export const halfUHeight = uHeight / 2;
/**
 * The width of the equipment front panel.
 */
export const equipmentPanelWidth = rackInnerWidth - equipmentClearance;
/**
 * The halved width of the equipment front panel.
 */
export const halfEquipmentPanelWidth = equipmentPanelWidth / 2;
/**
 * The height of the 4u equipment front panel.
 */
export const equipment1uPanelHeight = uHeight - equipmentClearance;
/**
 * The halved height of the 1u equipment front panel.
 */
export const halfEquipment1uPanelHeight = equipment1uPanelHeight / 2;
/**
 * The height of the 4u equipment front panel.
 */
export const equipment4uPanelHeight = 4 * uHeight - equipmentClearance;
/**
 * The halved height of the 4u equipment front panel.
 */
export const halfEquipment4uPanelHeight = equipment4uPanelHeight / 2;
/**
 * The height of the content of the 4u equipment front panel.
 */
export const equipment4uContentHeight = equipment4uPanelHeight - 2 * equipmentContentVerticalPadding;
/**
 * The halved depth of the equipment front panel.
 */
export const halfEquipmentPanelDepth = equipmentPanelDepth / 2;
/**
 * The width of the equipment body.
 */
export const equipmentBodyWidth = rackInnerWidth - 2 * rackRailWidth - equipmentClearance;
/**
 * The halved width of the equipment body.
 */
export const halfEquipmentBodyWidth = equipmentBodyWidth / 2;
/**
 * The height of the 1u equipment body.
 */
export const equipment1uBodyHeight = uHeight - equipmentClearance;
/**
 * The height of the 4u equipment body.
 */
export const equipment4uBodyHeight = 4 * uHeight - equipmentClearance;
/**
 * The halved depth of the equipment body.
 */
export const halfEquipmentBodyDepth = equipmentBodyDepth / 2;
/**
 * The halved redundant gap between equipments based on realistic engineering assemply considerations.
 */
export const halfEquipmentClearance = equipmentClearance / 2;
/**
 * The distance of the equipment on z axis from its normal position to its pulled out position.
 */
export const equipmentPulloutDistanceZ = halfRackOuterDepth + halfEquipmentBodyDepth + slotDistanceZ;
/**
 * The depth of the rack enclosure post.
 */
export const rackEnclosurePostDepth = halfRackOuterDepth - halfEquipmentBodyDepth;
/**
 * The depth of the rack enclosure beam.
 */
export const rackEnclosureBeamDepth = equipmentBodyDepth;
/**
 * The halved depth of the rack enclosure beam.
 */
export const halfRackEnclosureBeamDepth = rackEnclosureBeamDepth / 2;
/**
 * The decorative inner border radius of the applicable rack enclosure.
 */
export const rackEncolsureInnerRadius = rackEncolsureOuterRadius - rackEnclosureNarrowPostWidth;
/**
 * The outer height of the rack. The literal description used to calculate this height is as follows:
 * 
 * the height of the bottom edge of the rack enclosure +
 * the available inner height of the rack +
 * the clearance between the equipment and the lining +
 * lining height +
 * the clearance between the lining and the top edge of the rack enclosure
 * the height of the top edge of the rack encosure,
 * where lining height + the clearance between the lining and the top edge of the rack enclosure equals to
 * the inner radius of the rack enclosure.
 */
export const rackOuterHeight =
  rackEnclosureNarrowPostWidth +
  rackInnerHeight +
  halfEquipmentClearance +
  rackEncolsureInnerRadius +
  rackEnclosureNarrowPostWidth;
/**
 * The expected distance from the camera to the front surface of the cluster.
 */
export const cameraViewDistanceZ = rackOuterHeight * defaultCameraViewRackOuterHeightRatio / 2 / Math.tan(cameraFOV * Math.PI / 360);
/**
 * The width of the rack lining.
 */
export const rackLiningWidth = rackInnerWidth - equipmentClearance;
/**
 * The halved width of the rack lining.
 */
export const halfRackLiningWidth = rackLiningWidth / 2;
/**
 * The height of the rack lining.
 */
export const rackLiningHeight = rackEncolsureInnerRadius - halfEquipmentClearance;
/**
 * The halved height of the rack lining.
 */
export const halfRackLiningHeight = rackLiningHeight / 2;
/**
 * The border radius of the rack lining.
 */
export const rackLiningRadius = rackLiningHeight;
/**
 * The depth of the rack lining.
 */
export const rackLiningDepth = equipmentBodyDepth + 2 * equipmentPanelDepth;
/**
 * The halved width of a hard drive bay.
 */
export const halfHardDriveBayWidth = hardDriveBayWidth / 2;
/**
 * The halved height of a hard drive bay.
 */
export const halfHardDriveBayHeight = hardDriveBayHeight / 2;
/**
 * The halved depth of a hard drive bay.
 */
export const halfHardDriveBayDepth = hardDriveBayDepth / 2;
/**
 * The width of the hard drive slots on the storage node.
 */
export const hardDriveSlotWidth = hardDriveBayWidth + 2 * equipmentClearance;
/**
 * The height of the hard drive slots on the storage node.
 */
export const hardDriveSlotHeight = hardDriveBayHeight + 2 * equipmentClearance;
/**
 * The gap between the columns of the hard drive slots on a storage node.
 * 
 * This is calculated based on the assumption that there are 4 columns on a storage node, regardless of its u height.
 */
export const storageNodeHardDriveSlotHorizontalGap = (equipmentPanelWidth - equipmentContentHorizontalPadding - storageNodeStatusLightWidth - rackRailWidth - equipmentChassisWallThickness - 4 * hardDriveSlotWidth) / 4;
/**
 * The gap between the rows of the hard drive slots on a 4u storage node.
 * 
 * This is calculated based on the assumption that there are five rows on a 4u storage node.
 */
export const storageNode4uHardDriveSlotVerticalGap = (equipment4uContentHeight - 5 * hardDriveSlotHeight) / 4;
/**
 * The radius of a hard drive slot.
 */
export const storageNodeHardDriveSlotRadius = hardDriveBayRadius + equipmentClearance;

