import * as THREE from './three.module.min.js'
import * as ThreeWorld from './world.js'

import { envTexture } from './mesh/env_texture.js'

import { EffectComposer } from './a/postprocessing/EffectComposer.js'
import { RenderPass } from './a/postprocessing/RenderPass.js'
import { UnrealBloomPass } from './a/postprocessing/UnrealBloomPass.js'

export const newScene = function (world) {
  return new Scene(world);
};

class Scene {

  /**
   * 
   * @param {World} world 
   */
  constructor (world) {
    this.world = world;

    const viewportDimensions = world.domRoomWrapper.getBoundingClientRect();
    this.renderer = new THREE.WebGLRenderer({
      'canvas': world.domRoom
    });
    this.renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio, 2));
    this.renderer.setSize(viewportDimensions.width, viewportDimensions.height);

    this.scene = new THREE.Scene();
    this.scene.environment = envTexture;

    // post prosessing
    this.effectComposer = new EffectComposer(this.renderer);
    this.effectComposer.setPixelRatio(Math.min(globalThis.devicePixelRatio, 2));
    this.effectComposer.setSize(viewportDimensions.width, viewportDimensions.height);

    const renderPass = new RenderPass(this.scene, world.camera.camera);
    this.effectComposer.addPass(renderPass);

    const unrealBloomPass = new UnrealBloomPass();
    unrealBloomPass.strength = 0.36;
    unrealBloomPass.radius = 0.96;
    unrealBloomPass.threshold = 0.96;
    this.effectComposer.addPass(unrealBloomPass);

    this.scene.add(world.getRoomMeshes());
    this.scene.add(...world.getClusterMeshes());
    this.scene.add(...world.getRackMeshes());
    this.scene.add(...world.getSlotMeshes());
    this.scene.add(...world.getNodeMeshes());

    const roomLight = new THREE.HemisphereLight(0xffffff, 0xE1F1FA, 1.2);
    this.scene.add(roomLight);
    const roomShadowLight = new THREE.DirectionalLight(0xffffff, 0.96);
    roomShadowLight.position.set(0, 5, 3);
    roomShadowLight.castShadow = true;
    this.scene.add(roomShadowLight);

    this.frameClock = new THREE.Clock();
    this.lastFrameTime = this.frameClock.getElapsedTime();
    this.renderNextFrame();

    this.sizeOutdated = false;
  }

  getFrameDuration () {
    const currentFrameTime = this.frameClock.getElapsedTime();
    const frameDuration = currentFrameTime - this.lastFrameTime;
    this.lastFrameTime = currentFrameTime;

    return frameDuration;
  }

  renderNextFrame () {requestAnimationFrame(() => {

    this.frameDuration = this.getFrameDuration();

    this.world.camera.notifyNextFrame(this.frameDuration);
    this.world.raycaster.notifyNextFrame();
    this.respondToRaycasterIntersection();

    if (this.world.status === ThreeWorld.GRABBING_STATUS) {
      this.world.grabbingNode.notifyNextFrame(this.frameDuration);
    } else if (this.world.status === ThreeWorld.PUTTING_STATUS) {
      this.world.grabbingNode.notifyNextFrame(this.frameDuration);
    }
    
    if (this.sizeOutdated) {
      this.updateSize();
    }
    this.effectComposer.render();
    this.renderNextFrame();
  
  });}

  respondToRaycasterIntersection () {
    if (this.world.status === ThreeWorld.IDLE_STATUS && this.world.raycaster.firstIntersectedObject !== this.world.hoveringNode) {
      
      if (this.world.hoveringNode !== undefined) {
        this.world.hoveringNode.unhover();
      }
    
      this.world.hoveringNode = this.world.raycaster.firstIntersectedObject;

      if (this.world.hoveringNode !== undefined) {
        this.world.hoveringNode.hover();
        this.world.domRoomWrapper.style.cursor = 'grab';
      } else {
        this.world.domRoomWrapper.style.cursor = '';
      }

    } else if (this.world.status === ThreeWorld.GRABBING_STATUS && this.world.raycaster.firstIntersectedObject !== this.world.hoveringSlots[0]) {
      // fetch the new hovering slots
      const newHoveringSlots = [];
      const topHoveringSlot = this.world.raycaster.firstIntersectedObject;
      if ( topHoveringSlot !== undefined ) {
        for (let i = topHoveringSlot.index; i < topHoveringSlot.index + this.world.grabbingNode.uNumber && i < topHoveringSlot.rack.uCapacity; i++) {
          newHoveringSlots.push(topHoveringSlot.rack.slots[i]);
        }
      }

      // unhover the previously hovered slots if they are no longer hovered
      const unhoveredSlots = this.world.hoveringSlots.filter(slot => !newHoveringSlots.includes(slot));
      for (const unhoveredSlot of unhoveredSlots) {
        unhoveredSlot.unhover();
      }

      // determine whether the node can be placed into the selected slots
      this.world.hoveringSlots = newHoveringSlots;
      let slotAvailable = false;
      if (this.world.hoveringSlots.every(slot => slot.node === undefined || slot.node === this.world.grabbingNode) && this.world.hoveringSlots.length === this.world.grabbingNode.uNumber) {
       slotAvailable = true;
      }
      for (const slot of this.world.hoveringSlots) {
        slot.hover(slotAvailable);
      }
    }
  }

  requestUpdateSize () {
    this.sizeOutdated = true;
  }

  updateSize () {
    const viewportDimensions = this.world.domRoomWrapper.getBoundingClientRect();
    this.renderer.setSize(viewportDimensions.width, viewportDimensions.height);
    this.world.camera.camera.aspect = viewportDimensions.width / viewportDimensions.height;
    this.world.camera.camera.updateProjectionMatrix();
    this.effectComposer.setPixelRatio(Math.min(globalThis.devicePixelRatio, 2));
    this.effectComposer.setSize(viewportDimensions.width, viewportDimensions.height);
    this.sizeOutdated = false;
  }

}