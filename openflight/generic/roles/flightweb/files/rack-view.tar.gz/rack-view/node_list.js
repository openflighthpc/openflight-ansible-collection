import {
  ThreeNode,
  newRack,
} from './object.js'

export const newNodeList = function (cluster, world) {
  return new NodeList(cluster, world);
}

class NodeList {
  constructor(cluster, world) {
    this.domMenuWrapper = globalThis.document.getElementById('menu-wrapper');
    this.domNodeList = this.domMenuWrapper.getElementsByClassName('node-list')[0];
    this.domNodeList.innerHTML = "";
    this.cluster = cluster;
    this.world = world;
    this.generateNodeList();
  }

  groupedNodes() {
    return this.cluster.getGroupedNodes();
  }

  generateNodeList() {
    for (const type of ThreeNode.nodeTypes()) {
      this.addNodeType(type, this.groupedNodes()[type] === undefined ? 0 : this.groupedNodes()[type].length);
    }
  }

  addNodeType(type, number) {
    let nodeType = globalThis.document.createElement('span');
    const capitalizedType = type.replace(type.charAt(0), type.charAt(0).toUpperCase());
    nodeType.appendChild(globalThis.document.createTextNode(capitalizedType));
    this.domNodeList.appendChild(nodeType);

    let typeCount = globalThis.document.createElement('span');
    typeCount.id = `${type}-count`;
    typeCount.classList.add('node-type-count');
    typeCount.appendChild(globalThis.document.createTextNode(number));
    this.domNodeList.appendChild(typeCount);

    let btns = globalThis.document.createElement('div');
    btns.classList.add('node-list-row-buttons');
    this.domNodeList.appendChild(btns);

    let addBtn = globalThis.document.createElement('button');
    const uNumber = type === 'storage' ? 4 : 1;
    addBtn.classList.add(`${uNumber}-add-btn`);
    addBtn.appendChild(globalThis.document.createTextNode("+"));
    addBtn.addEventListener("click", this.addNode.bind(this));
    addBtn.dataset.type = type;
    btns.appendChild(addBtn);
    this.disableAddIfOutOfSpace();

    let removeBtn = globalThis.document.createElement('button');
    removeBtn.id = `${type}-remove-btn`;
    removeBtn.appendChild(globalThis.document.createTextNode("-"));
    removeBtn.addEventListener("click", this.removeNode.bind(this));
    removeBtn.dataset.type = type;
    if (number === 0) { removeBtn.disabled = true }
    btns.appendChild(removeBtn);
  }

  updateNodeCount(type) {
    const nodeCount = document.getElementById(`${type}-count`);
    if (this.groupedNodes()[type] !== undefined) {
      nodeCount.innerHTML = this.groupedNodes()[type].length;
      document.getElementById(`${type}-remove-btn`).disabled = false;
    } else {
      nodeCount.innerHTML = '0';
      document.getElementById(`${type}-remove-btn`).disabled = true;
    }
  }

  disableAddIfOutOfSpace() {
    for (const uNumber of [1, 4]) {
      const spaceForU = this.cluster.hasEmptySlot(uNumber) || this.cluster.canFitNewRack();
      for (const addBtn of globalThis.document.getElementsByClassName(`${uNumber}-add-btn`)) {
        addBtn.disabled = !spaceForU;
      }
    }
  }

  addNode(e) {
    const type = e.currentTarget.dataset.type;
    const uNumber = type === 'storage' ? 4 : 1;
    const id = this.cluster.generateUniqueNodeId(type);

    let slot = this.cluster.firstEmptySlot(uNumber);
    if (slot === undefined) {
      const rack = newRack(this.cluster);
      this.world.scene.scene.add(rack.groupMesh);
      this.world.scene.scene.add(...rack.getSlotMeshes());
      this.world.camera.updateFocusingCluster(this.cluster);
      slot = rack.slots[0];
    }
    
    const node = ThreeNode.newNode(slot.rack, slot.index, `${type}${id}`, type, uNumber, ThreeNode.RUNNING_STATUS);

    slot.node = node;
    this.world.scene.scene.add(node.groupMesh);
    this.updateWorld(type);
  }

  removeNode(e) {
    const type = e.currentTarget.dataset.type;
    const nodesOfType = this.groupedNodes()[type];
    let nodeToRemove = nodesOfType[nodesOfType.length - 1];

    nodeToRemove.removeFromSlots();
    this.cluster.removeNode(nodeToRemove);
    this.world.scene.scene.remove(nodeToRemove.groupMesh);
    this.updateWorld(type);
  }

  updateWorld(type) {
    this.updateNodeCount(type);
    this.disableAddIfOutOfSpace();
    this.world.saveToLocalStorage();
  }
}
