import * as ThreeWorld from './world.js'

import {
  ThreeCameraRaycaster,
} from './object.js'

export const newController = function (world) {
  return new Controller(world);
};

class Controller {

  /**
   * 
   * @param {World} world 
   */
  constructor (world) {
    this.world = world;

    this.world.domRoomWrapper.addEventListener('click', (e) => {
      this.handleClickEvent(e);
    });

    this.world.domRoomWrapper.addEventListener('mousemove', (e) => {
      this.requestCameraPan(e);
      this.updateRaycasterVector(e);
    });

    this.world.domRoomWrapper.addEventListener('mouseleave', (e) => {
      this.requestCameraRestoration();
    });

    const resizeObserver = new ResizeObserver((_e) => {
      this.world.scene.requestUpdateSize();
    });
    resizeObserver.observe(this.world.domRoomWrapper);
  }

  handleClickEvent (e) {
    if (this.world.status === ThreeWorld.IDLE_STATUS && this.world.hoveringNode !== undefined) {
      this.world.status = ThreeWorld.GRABBING_STATUS;
      this.world.grabbingNode = this.world.hoveringNode;
      this.world.hoveringNode = undefined;
      this.world.grabbingNode.requestLift();
      this.world.raycaster.mode = ThreeCameraRaycaster.SLOT_MODE;

      this.world.domRoomWrapper.style.cursor = 'grabbing';
    } else if (this.world.status === ThreeWorld.GRABBING_STATUS) {
      this.world.status = ThreeWorld.PUTTING_STATUS;
      
      if (
        this.world.hoveringSlots.every(slot => slot.node === undefined || slot.node === this.world.grabbingNode) &&
        this.world.hoveringSlots.length === this.world.grabbingNode.uNumber &&
        this.world.hoveringSlots[0] !== this.world.grabbingNode.slots[0]
      ) {
        this.world.grabbingNode.requestChangeSlot(this.world.hoveringSlots[0], () => {
          this.world.status = ThreeWorld.IDLE_STATUS;
          this.world.grabbingNode = undefined;
          this.world.hoveringSlots = [];

          this.world.saveToLocalStorage();
        });
      } else {
        this.world.grabbingNode.requestPushin(() => {
          this.world.status = ThreeWorld.IDLE_STATUS;
          this.world.grabbingNode = undefined;
          this.world.hoveringSlots = [];
        });
      }

      this.world.raycaster.mode = ThreeCameraRaycaster.NODE_MODE;
      this.world.grabbingNode.unhover();
      for (const slot of this.world.hoveringSlots) {
        slot.unhover();
      }
      this.world.domRoomWrapper.style.cursor = '';
    }
  }

  requestCameraPan (e) {
    this.world.camera.requestPan(e);
  }

  updateRaycasterVector (e) {
    this.world.raycaster.updateVector(e);
  }

  requestCameraRestoration () {
    this.world.camera.requestRestoration();
  }

}