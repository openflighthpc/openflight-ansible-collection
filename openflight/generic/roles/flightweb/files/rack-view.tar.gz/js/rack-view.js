globalThis.onload = async function () {
  const ThreeWorld = await import('/rack-view/world.js');

  // read dummy data
  let resourceInfo = {};

  const storedResources = localStorage.getItem('concertim-resources');
  if (storedResources !== null) {
    resourceInfo = JSON.parse(storedResources);
    globalThis.threeWorld = ThreeWorld.newWorldFromStorage(resourceInfo);
  } else {
    const res = await fetch('/rack-view/dc-resources.json');
    resourceInfo = await res.json();
    globalThis.threeWorld = ThreeWorld.newWorldFromJSON(resourceInfo);
  }

  // refresh dummy data from json file in local storage format
  // const res = await fetch('../storage-resources.json');
  // resourceInfo = await res.json();
  // ThreeWorld.newWorldFromStorage(resourceInfo);

  // refresh dummy data from json file in user defined format
  // const res = await fetch('../dc-resources.json');
  // resourceInfo = await res.json();
  // ThreeWorld.newWorldFromJSON(resourceInfo);
  
//   const cart = new THREE.Mesh(RenderingComponent.cartGeometry(), RenderingComponent.cartMaterial());
//   cart.position.x = cluster.racks.length * 4.8 + 3;
//   cart.position.y = 15.6;
//   cart.position.z = 9;
//   roomScene.add(cart);
  // const panel1 = new THREE.Mesh(RenderingComponent.cartGeometry(), RenderingComponent.cartMaterial());
  // panel1.position.y = 24.8;
  // panel1.position.z = 21.6;
  // roomScene.add(panel1);
//   const panel3 = new THREE.Mesh(RenderingComponent.cartGeometry(), RenderingComponent.cartMaterial());
//   panel3.position.x = cluster.racks.length * 4.8 + 3;
//   panel3.position.y = 8.4;
//   panel3.position.z = 9;
//   roomScene.add(panel3);
  // const topPanel = new THREE.Mesh(RenderingComponent.cartGeometry(), RenderingComponent.cartMaterial());
  // topPanel.position.y = 23;
  // topPanel.position.z = 9;
  // topPanel.scale.x = (cluster.racks.length * 1.6);
  // roomScene.add(topPanel);
}
