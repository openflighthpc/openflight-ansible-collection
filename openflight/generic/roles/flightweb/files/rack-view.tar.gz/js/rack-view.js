globalThis.onload = async function () {
  const ThreeWorld = await import('/rack-view/world.js');

  // read dummy data
  let resourceInfo = {};

  const URL = '/rack-view/dc-resources.json';
  const ms = Date.now();
  const res = await fetch(URL+"?dummy="+ms);
  resourceInfo = await res.json();
  globalThis.threeWorld = ThreeWorld.newWorldFromJSON(resourceInfo);

}
